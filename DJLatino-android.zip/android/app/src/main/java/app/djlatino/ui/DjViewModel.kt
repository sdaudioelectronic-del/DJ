package app.djlatino.ui

import android.app.Application
import android.net.Uri
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.djlatino.audio.AudioOut
import app.djlatino.audio.DecodeException
import app.djlatino.audio.Decoder
import app.djlatino.audio.Library
import app.djlatino.audio.MappedPcmSource
import app.djlatino.audio.MicCapture
import app.djlatino.audio.TrackItem
import app.djlatino.engine.Analysis
import app.djlatino.engine.Analyzer
import app.djlatino.engine.BpmDetector
import app.djlatino.engine.Genre
import app.djlatino.engine.MixerCore
import app.djlatino.engine.Synth
import app.djlatino.engine.TapTempo
import app.djlatino.engine.WavWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln

/** Estado observable de un plato para la UI. */
class DeckUi {
    var title by mutableStateOf<String?>(null)
    var artist by mutableStateOf("")
    var loadProgress by mutableStateOf<Float?>(null)   // no nulo mientras carga
    var peaks by mutableStateOf<FloatArray?>(null)
    var bpm by mutableStateOf<Double?>(null)
    var bpmManual by mutableStateOf(false)
    var genre by mutableStateOf(Genre.AUTO)
    var playing by mutableStateOf(false)
    var pitchFader by mutableStateOf(0.5f)
    var volume by mutableStateOf(1f)
    var eqLow by mutableStateOf(0f)
    var eqMid by mutableStateOf(0f)
    var eqHigh by mutableStateOf(0f)
    var filter by mutableStateOf(0f)
    var echo by mutableStateOf(false)
    var loopBeats by mutableStateOf(0.0)
    var synced by mutableStateOf(false)
    val hotCues = mutableStateListOf<Double?>(null, null, null, null)
    var cuePoint = 0.0
    var analysis: Analysis? = null
    val tap = TapTempo()
}

enum class PadSound(val label: String) { AIR_HORN("AIR HORN"), SIRENA("SIRENA"), LASER("LÁSER"), BOMBA("BOMBA") }

class DjViewModel(app: Application) : AndroidViewModel(app) {
    companion object {
        const val RATE = 44100
        const val PITCH_RANGE = 0.08
    }

    val mixer = MixerCore(RATE)
    private val audioOut = AudioOut(mixer)
    val decks = listOf(DeckUi(), DeckUi())
    private val loadJobs = arrayOfNulls<Job>(2)

    var crossfader by mutableStateOf(0.5f)
        private set
    var tracks by mutableStateOf<List<TrackItem>>(emptyList())
        private set
    var libraryLoading by mutableStateOf(false)
        private set
    var libraryFor by mutableStateOf<Int?>(null)
    var message by mutableStateOf<String?>(null)
    var recording by mutableStateOf(false)
        private set
    var hasDrop by mutableStateOf(false)
        private set
    var micRecording by mutableStateOf(false)
        private set

    private val pcmDir = File(app.cacheDir, "pcm")
    private val dropFile = File(app.filesDir, "mi_drop.f32")
    private val sounds = HashMap<PadSound, FloatArray>()
    private var drop: FloatArray? = null
    private var mic: MicCapture? = null
    private var recorder: WavWriter? = null

    init {
        pcmDir.deleteRecursively() // limpiar caché de sesiones anteriores
        pcmDir.mkdirs()
        audioOut.start()
        viewModelScope.launch(Dispatchers.Default) {
            val s = mapOf(
                PadSound.AIR_HORN to Synth.airHorn(RATE), PadSound.SIRENA to Synth.siren(RATE),
                PadSound.LASER to Synth.laser(RATE), PadSound.BOMBA to Synth.boom(RATE),
            )
            val d = MicCapture.load(dropFile)
            withContext(Dispatchers.Main) {
                sounds.putAll(s)
                drop = d
                hasDrop = d != null
            }
        }
    }

    // ---------- Biblioteca ----------
    fun refreshLibrary() {
        libraryLoading = true
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                try { Library.query(getApplication<Application>()) } catch (e: Exception) { emptyList() }
            }
            tracks = list
            libraryLoading = false
        }
    }

    fun loadTrack(d: Int, uri: Uri, title: String?, artist: String?) {
        libraryFor = null
        loadJobs[d]?.cancel()
        val ui = decks[d]
        val deck = mixer.decks[d]
        deck.playing = false
        ui.playing = false
        ui.title = title ?: Library.displayName(getApplication<Application>(), uri)
        ui.artist = artist ?: ""
        ui.loadProgress = 0f
        ui.peaks = null
        ui.bpm = null
        ui.bpmManual = false
        ui.loopBeats = 0.0
        ui.synced = false
        for (i in 0 until 4) ui.hotCues[i] = null
        ui.cuePoint = 0.0
        loadJobs[d] = viewModelScope.launch {
            try {
                val src = withContext(Dispatchers.IO) {
                    Decoder.decode(getApplication<Application>(), uri, pcmDir) { p ->
                        viewModelScope.launch(Dispatchers.Main) { if (ui.loadProgress != null) ui.loadProgress = p }
                    }
                }
                val old = deck.source as? MappedPcmSource
                deck.load(src)
                old?.file?.delete()
                ui.loadProgress = null
                val analysis = withContext(Dispatchers.Default) { Analyzer.analyze(src) }
                ui.analysis = analysis
                ui.peaks = analysis.peaks
                detectBpm(d)
            } catch (e: DecodeException) {
                ui.loadProgress = null
                ui.title = null
                message = e.message
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                ui.loadProgress = null
                ui.title = null
                message = "No se pudo cargar la canción"
            }
        }
    }

    private fun detectBpm(d: Int) {
        val ui = decks[d]
        val a = ui.analysis ?: return
        val genre = ui.genre
        viewModelScope.launch {
            val bpm = withContext(Dispatchers.Default) { BpmDetector.detect(a.env, a.envRate, genre) }
            ui.bpm = bpm
            ui.bpmManual = false
            mixer.decks[d].bpm = bpm ?: 0.0
        }
    }

    // ---------- Transporte ----------
    fun togglePlay(d: Int) {
        val deck = mixer.decks[d]
        if (deck.source == null) { libraryFor = d; return }
        deck.playing = !deck.playing
        decks[d].playing = deck.playing
    }

    /** CUE: en pausa marca el punto; reproduciendo vuelve al punto y pausa. */
    fun cue(d: Int) {
        val deck = mixer.decks[d]
        val ui = decks[d]
        if (deck.source == null) return
        if (deck.playing) {
            deck.playing = false
            ui.playing = false
            deck.seekRequest = ui.cuePoint
        } else {
            ui.cuePoint = deck.position
            message = "Punto CUE marcado"
        }
    }

    fun seekFraction(d: Int, f: Float) {
        val src = mixer.decks[d].source ?: return
        mixer.decks[d].seekRequest = f.coerceIn(0f, 1f).toDouble() * (src.frames - 1)
    }

    fun setPitch(d: Int, v: Float) {
        decks[d].pitchFader = v
        decks[d].synced = false
        mixer.decks[d].tempo = 1.0 + (v - 0.5) * 2 * PITCH_RANGE
    }

    /** Iguala el tempo al otro plato, eligiendo ×½, ×1 o ×2 (p. ej. reguetón 95 ↔ merengue 190). */
    fun sync(d: Int) {
        val me = decks[d]
        val other = decks[1 - d]
        val myBpm = me.bpm
        val otherBpm = other.bpm
        if (myBpm == null || otherBpm == null) { message = "Falta el BPM de algún plato"; return }
        val target = otherBpm * mixer.decks[1 - d].tempo
        val ratio = listOf(0.5, 1.0, 2.0).map { target * it / myBpm }.minByOrNull { abs(ln(it)) }!!
        if (ratio < 0.75 || ratio > 1.33) { message = "Tempos muy distintos para sincronizar"; return }
        mixer.decks[d].tempo = ratio
        me.pitchFader = (0.5 + (ratio - 1.0) / (2 * PITCH_RANGE)).toFloat().coerceIn(0f, 1f)
        me.synced = true
    }

    fun cycleGenre(d: Int) {
        decks[d].genre = decks[d].genre.next()
        detectBpm(d)
    }

    fun redetect(d: Int) = detectBpm(d)

    fun halveBpm(d: Int) = setManualBpm(d, decks[d].bpm?.div(2))
    fun doubleBpm(d: Int) = setManualBpm(d, decks[d].bpm?.times(2))
    fun tapBpm(d: Int) = decks[d].tap.tap(System.currentTimeMillis())?.let { setManualBpm(d, it) }

    private fun setManualBpm(d: Int, bpm: Double?) {
        if (bpm == null || bpm < 40 || bpm > 250) return
        decks[d].bpm = Math.round(bpm * 10) / 10.0
        decks[d].bpmManual = true
        mixer.decks[d].bpm = bpm
    }

    // ---------- Plato ----------
    private val lastScratchNs = LongArray(2)

    fun scratch(d: Int, deltaDeg: Float) {
        val deck = mixer.decks[d]
        val now = System.nanoTime()
        val dt = ((now - lastScratchNs[d]) / 1e9).coerceIn(0.005, 0.1)
        lastScratchNs[d] = now
        // Una vuelta = 1,8 s de audio (33⅓ rpm)
        val speed = (deltaDeg / 360.0 * 1.8) / dt
        deck.scratching = true
        deck.scratchSpeed = speed.coerceIn(-8.0, 8.0)
        deck.scratchStampNs = now
    }

    fun scratchEnd(d: Int) {
        mixer.decks[d].scratching = false
    }

    fun nudgeRing(d: Int, deltaDeg: Float) {
        val deck = mixer.decks[d]
        deck.nudge = (deltaDeg * 0.01).coerceIn(-0.12, 0.12)
        deck.nudgeStampNs = System.nanoTime()
    }

    fun holdNudge(d: Int, amount: Double) {
        mixer.decks[d].holdNudge = amount
    }

    // ---------- Mezclador ----------
    fun setCrossfader(v: Float) { crossfader = v; mixer.crossfader = v }
    fun setVolume(d: Int, v: Float) { decks[d].volume = v; mixer.decks[d].volume = v }
    fun setEqLow(d: Int, v: Float) { decks[d].eqLow = v; mixer.decks[d].eqLow = v }
    fun setEqMid(d: Int, v: Float) { decks[d].eqMid = v; mixer.decks[d].eqMid = v }
    fun setEqHigh(d: Int, v: Float) { decks[d].eqHigh = v; mixer.decks[d].eqHigh = v }
    fun setFilter(d: Int, v: Float) { decks[d].filter = v; mixer.decks[d].filter = v }
    fun toggleEcho(d: Int) { decks[d].echo = !decks[d].echo; mixer.decks[d].echoOn = decks[d].echo }

    // ---------- Loops, cues y efectos ----------
    fun loop(d: Int, beats: Double) {
        val ui = decks[d]
        if (mixer.decks[d].source == null) return
        if (ui.loopBeats == beats) {
            mixer.decks[d].loopRequestBeats = -1.0
            ui.loopBeats = 0.0
        } else {
            mixer.decks[d].loopRequestBeats = beats
            ui.loopBeats = beats
        }
    }

    fun hotCue(d: Int, slot: Int) {
        val deck = mixer.decks[d]
        if (deck.source == null) return
        val saved = decks[d].hotCues[slot]
        if (saved == null) decks[d].hotCues[slot] = deck.position
        else deck.seekRequest = saved
    }

    fun clearHotCue(d: Int, slot: Int) { decks[d].hotCues[slot] = null }

    fun spinback(d: Int) {
        if (mixer.decks[d].source == null) return
        mixer.decks[d].effectRequest = 1
        decks[d].playing = false
    }

    fun brake(d: Int) {
        if (mixer.decks[d].source == null) return
        mixer.decks[d].effectRequest = 2
        decks[d].playing = false
    }

    fun playPad(s: PadSound) { sounds[s]?.let { mixer.trigger(it) } }

    // ---------- Drop propio (micrófono) ----------
    fun startDropRecording(): Boolean {
        val m = MicCapture(RATE)
        if (!m.start()) { message = "No se pudo usar el micrófono"; return false }
        mic = m
        micRecording = true
        return true
    }

    fun stopDropRecording() {
        val m = mic ?: return
        mic = null
        micRecording = false
        viewModelScope.launch {
            val data = withContext(Dispatchers.IO) { m.stop() }
            if (data.size < RATE / 5) { message = "Drop muy corto: mantén pulsado mientras hablas"; return@launch }
            drop = data
            hasDrop = true
            withContext(Dispatchers.IO) { MicCapture.save(dropFile, data) }
            message = "¡Drop guardado! Tócalo para lanzarlo"
        }
    }

    fun playDrop() { drop?.let { mixer.trigger(it, 1f) } }

    // ---------- Grabación de la mezcla ----------
    fun toggleRecording() {
        if (recording) stopRecording() else startRecording()
    }

    private fun startRecording() {
        val dir = getApplication<Application>().getExternalFilesDir(Environment.DIRECTORY_MUSIC)
            ?: getApplication<Application>().filesDir
        val name = "mezcla_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".wav"
        val w = try { WavWriter(File(dir, name), RATE) } catch (e: Exception) { message = "No se pudo crear el archivo"; return }
        recorder = w
        audioOut.recorder = w
        recording = true
    }

    private fun stopRecording() {
        val w = recorder ?: return
        recorder = null
        audioOut.recorder = null
        recording = false
        viewModelScope.launch {
            val where = withContext(Dispatchers.IO) {
                delay(50) // deja terminar el bloque en curso
                w.close()
                try { Library.publishRecording(getApplication<Application>(), w.file) } catch (e: Exception) { w.file.absolutePath }
            }
            message = "Mezcla guardada en $where"
        }
    }

    fun recordingSeconds(): Double = recorder?.seconds() ?: 0.0

    override fun onCleared() {
        if (recording) {
            audioOut.recorder = null
            try { recorder?.close() } catch (_: Exception) {}
        }
        audioOut.stop()
        mic?.stop()
        super.onCleared()
    }
}
