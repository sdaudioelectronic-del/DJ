package app.djlatino.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import app.djlatino.engine.MixerCore
import app.djlatino.engine.WavWriter

/** Hilo de audio: pide bloques al mezclador y los envía a AudioTrack (modo baja latencia). */
class AudioOut(private val mixer: MixerCore) {
    companion object { const val BLOCK = 256 }

    @Volatile private var running = false
    @Volatile var recorder: WavWriter? = null
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "dj-audio").also { it.start() }
    }

    private fun loop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val rate = mixer.outRate
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, BLOCK * 2 * 4 * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        val buf = FloatArray(BLOCK * 2)
        track.play()
        try {
            while (running) {
                mixer.render(buf, BLOCK, System.nanoTime())
                recorder?.let { r -> try { r.write(buf, BLOCK) } catch (_: Exception) { recorder = null } }
                track.write(buf, 0, buf.size, AudioTrack.WRITE_BLOCKING)
            }
        } finally {
            try { track.stop() } catch (_: Exception) {}
            track.release()
        }
    }

    fun stop() {
        running = false
        thread?.join(500)
        thread = null
    }
}
