package app.djlatino.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Graba un drop corto (máx. [maxSeconds]) desde el micrófono, mono float a [rate]. */
class MicCapture(private val rate: Int, private val maxSeconds: Int = 6) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var data = FloatArray(0)
    private var length = 0

    /** Requiere permiso RECORD_AUDIO concedido (lo verifica quien llama). */
    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (running) return false
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return false
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
        } catch (e: Exception) { return false }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return false }
        data = FloatArray(rate * maxSeconds)
        length = 0
        running = true
        thread = Thread({
            val chunk = ShortArray(1024)
            rec.startRecording()
            try {
                while (running && length < data.size) {
                    val n = rec.read(chunk, 0, chunk.size)
                    if (n <= 0) continue
                    val m = minOf(n, data.size - length)
                    for (i in 0 until m) data[length + i] = chunk[i] / 32768f
                    length += m
                }
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
                running = false
            }
        }, "dj-mic").also { it.start() }
        return true
    }

    /** Detiene y devuelve el audio normalizado, sin silencio inicial. */
    fun stop(): FloatArray {
        running = false
        thread?.join(1000)
        thread = null
        var start = 0
        while (start < length && kotlin.math.abs(data[start]) < 0.02f) start++
        val out = data.copyOfRange(start, length)
        val peak = out.maxOfOrNull { kotlin.math.abs(it) } ?: 0f
        if (peak > 0.01f) { val g = 0.9f / peak; for (i in out.indices) out[i] *= g }
        // fundido de salida de 30 ms para que no haga clic
        val fade = minOf(out.size, rate * 30 / 1000)
        for (i in 0 until fade) out[out.size - 1 - i] *= i.toFloat() / fade
        return out
    }

    companion object {
        fun save(file: File, samples: FloatArray) {
            val bb = ByteBuffer.allocate(samples.size * 4).order(ByteOrder.LITTLE_ENDIAN)
            bb.asFloatBuffer().put(samples)
            file.writeBytes(bb.array())
        }

        fun load(file: File): FloatArray? {
            if (!file.exists() || file.length() < 4) return null
            val bb = ByteBuffer.wrap(file.readBytes()).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
            return FloatArray(bb.remaining()).also { bb.get(it) }
        }
    }
}
