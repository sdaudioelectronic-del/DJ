package app.djlatino.engine

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Sonidos de pads generados por código: 100 % propios, sin licencias. Mono, [-1,1]. */
object Synth {
    private fun saw(phase: Double): Double = 2.0 * (phase - Math.floor(phase + 0.5))

    /** Bocina de aire: tres golpes cortos y uno largo, acorde desafinado de sierras. */
    fun airHorn(fs: Int): FloatArray {
        val pattern = listOf(0.11 to 0.05, 0.11 to 0.05, 0.11 to 0.05, 0.75 to 0.0)
        val total = pattern.sumOf { it.first + it.second }
        val out = FloatArray((total * fs).toInt())
        val freqs = doubleArrayOf(440.0, 446.0, 554.0, 660.0)
        var t0 = 0.0
        for ((on, off) in pattern) {
            val start = (t0 * fs).toInt()
            val len = (on * fs).toInt()
            for (i in 0 until len) {
                val t = (start + i).toDouble() / fs
                var s = 0.0
                for (f in freqs) s += saw(t * f)
                val env = minOf(1.0, i / (0.01 * fs)) * minOf(1.0, (len - i) / (0.02 * fs))
                out[start + i] = (Math.tanh(s * 0.6) * 0.7 * env).toFloat()
            }
            t0 += on + off
        }
        return out
    }

    /** Sirena: barrido senoidal subiendo y bajando. */
    fun siren(fs: Int, seconds: Double = 2.0): FloatArray {
        val out = FloatArray((seconds * fs).toInt())
        var phase = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / fs
            val f = 900.0 + 500.0 * sin(2 * PI * 1.5 * t)
            phase += f / fs
            val env = minOf(1.0, t / 0.05) * minOf(1.0, (seconds - t) / 0.2)
            val s = sin(2 * PI * phase) + 0.3 * sin(4 * PI * phase)
            out[i] = (s * 0.5 * env).toFloat()
        }
        return out
    }

    /** Láser: barrido descendente rápido. */
    fun laser(fs: Int): FloatArray {
        val dur = 0.35
        val out = FloatArray((dur * fs).toInt())
        var phase = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / fs
            val f = 2400.0 * exp(-t * 9) + 120
            phase += f / fs
            out[i] = (saw(phase) * 0.5 * exp(-t * 4)).toFloat()
        }
        return out
    }

    /** Bomba: golpe grave con caída de tono + ruido inicial. */
    fun boom(fs: Int): FloatArray {
        val dur = 1.4
        val out = FloatArray((dur * fs).toInt())
        val rnd = Random(7)
        var phase = 0.0
        for (i in out.indices) {
            val t = i.toDouble() / fs
            val f = 38.0 + 90.0 * exp(-t * 18)
            phase += f / fs
            val body = sin(2 * PI * phase) * exp(-t * 2.2)
            val noise = (rnd.nextDouble() * 2 - 1) * exp(-t * 40) * 0.6
            out[i] = (Math.tanh((body + noise) * 1.6) * 0.85).toFloat()
        }
        return out
    }
}
