// GENERADO por gen_compose.py desde tokens.json — no editar a mano.
package app.djlatino.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Immutable
data class DjColors(
    val bg: Color = Color(0xFF0E0F12),
    val surface: Color = Color(0xFF17191E),
    val surface2: Color = Color(0xFF20232A),
    val surface3: Color = Color(0xFF2A2E37),
    val border: Color = Color(0xFF2F333C),
    val borderInput: Color = Color(0xFF6B7280),
    val text: Color = Color(0xFFF2F3F5),
    val textMuted: Color = Color(0xFFA3A8B3),
    val textDisabled: Color = Color(0xFF7A7F89),
    val accent: Color = Color(0xFFE6E8EC),
    val onAccent: Color = Color(0xFF0E0F12),
    val deckA: Color = Color(0xFF4DA3FF),
    val onDeckA: Color = Color(0xFF0E0F12),
    val deckB: Color = Color(0xFFFF9F43),
    val onDeckB: Color = Color(0xFF0E0F12),
    val danger: Color = Color(0xFFFF5A5F),
    val onDanger: Color = Color(0xFF0E0F12),
    val rec: Color = Color(0xFFFF3B47),
    val success: Color = Color(0xFF3DDC84),
    val warning: Color = Color(0xFFFFC94D),
    val vip: Color = Color(0xFFF5C451),
    val onVip: Color = Color(0xFF0E0F12),
    val focusRing: Color = Color(0xFFFFFFFF),
    val scrim: Color = Color(0xB3000000),
)

object DjSpace {
    val s0 = 0.dp
    val s1 = 4.dp
    val s2 = 8.dp
    val s3 = 12.dp
    val s4 = 16.dp
    val s5 = 24.dp
    val s6 = 32.dp
    val s7 = 48.dp
}

object DjRadius {
    val sm = 4.dp
    val md = 8.dp
    val lg = 12.dp
    val full = 999.dp
}

object DjSize {
    val touchMin = 48.dp
    val pad = 56.dp
    val knobSm = 40.dp
    val knobMd = 52.dp
    val transport = 56.dp
    val faderTrackW = 8.dp
    val faderThumbW = 36.dp
    val faderThumbH = 20.dp
    val topbarH = 40.dp
    val bottomTabsH = 40.dp
    val panelH = 128.dp
}

object DjMotion {
    const val press = 80
    const val toggle = 150
    const val sheet = 250
    const val blinkRec = 1000
}

object DjType {
    val micro = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight(600), fontFamily = Inter)
    val caption = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight(500), fontFamily = Inter)
    val body = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight(400), fontFamily = Inter)
    val label = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight(600), fontFamily = Inter)
    val title = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight(600), fontFamily = Inter)
    val heading = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight(700), fontFamily = Inter)
    val bpm = TextStyle(fontSize = 28.sp, lineHeight = 32.sp, fontWeight = FontWeight(700), fontFamily = Inter)
    val display = TextStyle(fontSize = 40.sp, lineHeight = 44.sp, fontWeight = FontWeight(800), fontFamily = Inter)
}

val LocalDjColors = staticCompositionLocalOf { DjColors() }
