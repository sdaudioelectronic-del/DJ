package app.djlatino.engine

import kotlin.math.abs

/** Resultado del análisis: forma de onda resumida y envolvente de energía para el BPM. */
class Analysis(val peaks: FloatArray, val env: FloatArray, val envRate: Double)

object Analyzer {
    const val HOP = 256
    const val PEAK_BINS = 600

    fun analyze(src: PcmSource): Analysis {
        val frames = src.frames
        val peaks = FloatArray(PEAK_BINS)
        val envSize = frames / HOP
        val env = FloatArray(maxOf(envSize, 1))
        val framesPerBin = maxOf(1, frames / PEAK_BINS)
        var acc = 0.0
        for (i in 0 until frames) {
            val m = (src.sample(i, 0) + src.sample(i, 1)) * 0.5f
            val bin = (i / framesPerBin).coerceAtMost(PEAK_BINS - 1)
            val a = abs(m)
            if (a > peaks[bin]) peaks[bin] = a
            acc += m * m
            if ((i + 1) % HOP == 0) {
                val e = (i + 1) / HOP - 1
                if (e < env.size) env[e] = (acc / HOP).toFloat()
                acc = 0.0
            }
        }
        val max = peaks.maxOrNull() ?: 0f
        if (max > 0f) for (i in peaks.indices) peaks[i] /= max
        return Analysis(peaks, env, src.sampleRate.toDouble() / HOP)
    }
}
