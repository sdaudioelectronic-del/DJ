package app.djlatino.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.text.font.FontFamily

/**
 * Tipografía: por ahora la del sistema (Roboto). Para usar Inter (SIL OFL), añade los .ttf a res/font/
 * y cambia esta línea por FontFamily(Font(R.font.inter_regular), ...).
 */
val Inter: FontFamily = FontFamily.Default

object Dj {
    val colors: DjColors
        @Composable @ReadOnlyComposable get() = LocalDjColors.current
}

@Composable
fun DjTheme(content: @Composable () -> Unit) {
    val c = DjColors()
    // Material solo para componentes estándar (menús, campos de texto); los controles DJ usan Dj.colors.
    val scheme = darkColorScheme(
        primary = c.accent, onPrimary = c.onAccent,
        background = c.bg, onBackground = c.text,
        surface = c.surface2, onSurface = c.text,
        surfaceVariant = c.surface3, onSurfaceVariant = c.textMuted,
        surfaceContainer = c.surface2,
        outline = c.borderInput, outlineVariant = c.border,
        error = c.danger, onError = c.onDanger,
    )
    CompositionLocalProvider(LocalDjColors provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
