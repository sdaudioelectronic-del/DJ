package app.djlatino.engine

import kotlin.math.floor
import kotlin.math.pow

/** Audio decodificado: estéreo, acceso aleatorio por frame. */
interface PcmSource {
    val frames: Int
    val sampleRate: Int
    /** canal 0 = izquierdo, 1 = derecho; valor en [-1, 1]. */
    fun sample(frame: Int, ch: Int): Float
}

/** PCM en memoria (pruebas y samples cortos). Intercalado L,R. */
class FloatArraySource(private val data: FloatArray, override val sampleRate: Int) : PcmSource {
    override val frames: Int = data.size / 2
    override fun sample(frame: Int, ch: Int): Float = data[frame * 2 + ch]
}

/**
 * Un plato. La UI escribe los campos @Volatile; el hilo de audio los lee.
 * Solo el hilo de audio escribe [position]. La UI pide saltos con [seekRequest].
 */
class Deck {
    @Volatile var source: PcmSource? = null

    // Transporte
    @Volatile var playing = false
    @Volatile var tempo = 1.0
    @Volatile var position = 0.0            // en frames de la fuente
        private set
    @Volatile var seekRequest = Double.NaN  // frames; NaN = nada

    // Scratch y nudge
    @Volatile var scratching = false
    @Volatile var scratchSpeed = 0.0
    @Volatile var scratchStampNs = 0L
    @Volatile var nudge = 0.0               // desviación temporal desde el anillo del plato
    @Volatile var nudgeStampNs = 0L
    @Volatile var holdNudge = 0.0           // botones +/- mantenidos
    private var scratchCurrent = 0.0

    // Mezclador
    @Volatile var volume = 1.0f
    @Volatile var eqLow = 0f                // -1..1
    @Volatile var eqMid = 0f
    @Volatile var eqHigh = 0f
    @Volatile var filter = 0f               // -1 LPF .. 0 .. +1 HPF
    @Volatile var echoOn = false

    // Análisis
    @Volatile var bpm = 0.0                 // 0 = desconocido

    // Loop
    @Volatile var loopRequestBeats = 0.0    // >0 activar N tiempos; <0 salir
    @Volatile var loopActive = false
        private set
    private var loopStart = 0.0
    private var loopEnd = 0.0

    // Efectos de salida (1 = spinback, 2 = freno)
    @Volatile var effectRequest = 0
    private var effect = 0
    private var effectT = 0.0
    private var effectStartSpeed = 0.0

    val dsp = DeckDsp()

    fun durationSec(): Double = source?.let { it.frames.toDouble() / it.sampleRate } ?: 0.0
    fun positionSec(): Double = source?.let { position / it.sampleRate } ?: 0.0

    /** Llamado por la UI al cargar pista nueva. */
    fun load(newSource: PcmSource) {
        playing = false
        effect = 0
        loopActive = false
        source = newSource
        seekRequest = 0.0
        bpm = 0.0
    }

    /** Renderiza [frames] frames estéreo intercalados en [out] (sobrescribe). Devuelve false si quedó en silencio. */
    fun render(out: FloatArray, frames: Int, outRate: Int, nowNs: Long): Boolean {
        val src = source
        if (src == null || src.frames < 2) {
            out.fill(0f, 0, frames * 2)
            return false
        }
        if (!seekRequest.isNaN()) {
            position = seekRequest.coerceIn(0.0, (src.frames - 1).toDouble())
            seekRequest = Double.NaN
        }
        handleLoopRequest(src)
        if (effectRequest != 0) {
            effect = effectRequest
            effectRequest = 0
            effectT = 0.0
            effectStartSpeed = if (playing) tempo else 1.0
            playing = true
        }

        val blockSec = frames.toDouble() / outRate
        val speed: Double = when {
            scratching -> {
                val target = if (nowNs - scratchStampNs > 60_000_000L) 0.0 else scratchSpeed
                scratchCurrent += (target - scratchCurrent) * 0.4
                scratchCurrent
            }
            effect == 1 -> { // spinback: hacia atrás rápido y frenando
                effectT += blockSec
                val dur = 0.9
                if (effectT >= dur) { effect = 0; playing = false; 0.0 } else -4.0 * (1 - effectT / dur).pow(1.5)
            }
            effect == 2 -> { // freno de tornamesa
                effectT += blockSec
                val dur = 1.3
                if (effectT >= dur) { effect = 0; playing = false; 0.0 } else effectStartSpeed * (1 - effectT / dur)
            }
            playing -> {
                val n = if (nowNs - nudgeStampNs > 80_000_000L) 0.0 else nudge
                tempo * (1 + n + holdNudge)
            }
            else -> 0.0
        }
        if (!scratching) scratchCurrent = 0.0

        if (speed == 0.0) {
            out.fill(0f, 0, frames * 2)
            dsp.process(out, frames, this, outRate) // deja sonar la cola del eco
            return false
        }

        val step = speed * src.sampleRate / outRate
        val last = src.frames - 1
        var pos = position
        for (i in 0 until frames) {
            val idx = floor(pos).toInt().coerceIn(0, last)
            val frac = (pos - idx).toFloat()
            val nxt = if (idx + 1 > last) last else idx + 1
            val l0 = src.sample(idx, 0); val l1 = src.sample(nxt, 0)
            val r0 = src.sample(idx, 1); val r1 = src.sample(nxt, 1)
            out[i * 2] = l0 + (l1 - l0) * frac
            out[i * 2 + 1] = r0 + (r1 - r0) * frac
            pos += step
            if (loopActive && step > 0 && pos >= loopEnd) pos -= (loopEnd - loopStart)
            if (pos >= last) {
                pos = last.toDouble()
                if (!scratching) { playing = false; effect = 0 }
            }
            if (pos < 0) pos = 0.0
        }
        position = pos
        dsp.process(out, frames, this, outRate)
        return true
    }

    private fun handleLoopRequest(src: PcmSource) {
        val req = loopRequestBeats
        if (req == 0.0) return
        loopRequestBeats = 0.0
        if (req < 0) { loopActive = false; return }
        val beatSec = 60.0 / (if (bpm > 0) bpm else 120.0)
        loopStart = position
        loopEnd = (position + req * beatSec * src.sampleRate).coerceAtMost((src.frames - 1).toDouble())
        loopActive = loopEnd - loopStart > 16
    }
}

/** Cadena de efectos del canal: EQ 3 bandas, filtro LPF/HPF y eco. */
class DeckDsp {
    private val low = arrayOf(Biquad(), Biquad())
    private val mid = arrayOf(Biquad(), Biquad())
    private val high = arrayOf(Biquad(), Biquad())
    private val filt = arrayOf(Biquad(), Biquad())
    private var lastLow = Float.NaN
    private var lastMid = Float.NaN
    private var lastHigh = Float.NaN
    private var lastFilter = Float.NaN
    private var lastRate = 0
    private var filterOn = false

    private var echoBuf = FloatArray(0)
    private var echoPos = 0

    /** -1 → casi apagado (-26 dB), 0 → plano, +1 → +6 dB. */
    private fun knobToDb(v: Float): Double = if (v < 0) v * 26.0 else v * 6.0

    fun process(buf: FloatArray, frames: Int, deck: Deck, rate: Int) {
        val fs = rate.toDouble()
        if (rate != lastRate) {
            lastRate = rate
            echoBuf = FloatArray(rate * 2 * 2) // 2 s estéreo
            echoPos = 0
            lastLow = Float.NaN; lastMid = Float.NaN; lastHigh = Float.NaN; lastFilter = Float.NaN
        }
        val lo = deck.eqLow; val mi = deck.eqMid; val hi = deck.eqHigh; val fi = deck.filter
        if (lo != lastLow) { lastLow = lo; for (b in low) b.setLowShelf(fs, 200.0, knobToDb(lo)) }
        if (mi != lastMid) { lastMid = mi; for (b in mid) b.setPeaking(fs, 1000.0, knobToDb(mi), 0.7) }
        if (hi != lastHigh) { lastHigh = hi; for (b in high) b.setHighShelf(fs, 3500.0, knobToDb(hi)) }
        if (fi != lastFilter) {
            lastFilter = fi
            filterOn = kotlin.math.abs(fi) > 0.03f
            for (b in filt) {
                if (fi < -0.03f) b.setLowPass(fs, 18000.0 * 0.011.pow((-fi).toDouble()), 0.9)      // 18 kHz → ~200 Hz
                else if (fi > 0.03f) b.setHighPass(fs, 20.0 * 250.0.pow(fi.toDouble()), 0.9)       // 20 Hz → 5 kHz
                else { b.setBypass(); b.reset() }
            }
        }
        val eqFlat = lo == 0f && mi == 0f && hi == 0f
        for (i in 0 until frames) {
            for (ch in 0..1) {
                var x = buf[i * 2 + ch]
                if (!eqFlat) x = high[ch].process(mid[ch].process(low[ch].process(x)))
                if (filterOn) x = filt[ch].process(x)
                buf[i * 2 + ch] = x
            }
        }
        // Eco sincronizado a 3/4 de tiempo (o 375 ms si no hay BPM)
        val delaySec = if (deck.bpm > 0) 60.0 / deck.bpm * 0.75 else 0.375
        val delayFrames = (delaySec * rate).toInt().coerceIn(1, rate * 2 - 1)
        val size = echoBuf.size / 2
        val wet = if (deck.echoOn) 0.45f else 0f
        for (i in 0 until frames) {
            val readPos = (echoPos - delayFrames + size) % size
            for (ch in 0..1) {
                val delayed = echoBuf[readPos * 2 + ch]
                val x = buf[i * 2 + ch]
                echoBuf[echoPos * 2 + ch] = x * wet + delayed * 0.5f   // la cola decae sola al apagar
                buf[i * 2 + ch] = x + delayed
            }
            echoPos = (echoPos + 1) % size
        }
    }
}
