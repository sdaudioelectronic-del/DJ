package app.djlatino.engine

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln

/** Rango de BPM por género: evita que el detector entregue el doble o la mitad. */
enum class Genre(val label: String, val minBpm: Double, val maxBpm: Double) {
    AUTO("Auto", 78.0, 160.0),
    REGGAETON("Reguetón", 84.0, 108.0),
    MERENGUE("Merengue", 110.0, 175.0),
    SALSA("Salsa", 140.0, 225.0);

    fun next(): Genre = entries[(ordinal + 1) % entries.size]
}

object BpmDetector {
    /**
     * [env]: energía por ventana (hop) de la señal mono; [envRate]: ventanas por segundo.
     * Autocorrelación de la fuerza de onsets dentro del rango del género.
     */
    fun detect(env: FloatArray, envRate: Double, genre: Genre): Double? {
        if (env.size < envRate * 6) return null
        val n = env.size
        val onset = DoubleArray(n)
        var prev = ln(1e-9 + env[0])
        for (i in 1 until n) {
            val cur = ln(1e-9 + env[i])
            val d = cur - prev
            onset[i] = if (d > 0) d else 0.0
            prev = cur
        }
        val mean = onset.average()
        for (i in 0 until n) onset[i] -= mean

        val minLag = floor(60.0 * envRate / genre.maxBpm).toInt().coerceAtLeast(2)
        val maxLag = ceil(60.0 * envRate / genre.minBpm).toInt()
        if (maxLag + 2 >= n / 2) return null
        val ac = DoubleArray(maxLag + 3)
        for (lag in (minLag - 1)..(maxLag + 1)) {
            var s = 0.0
            for (i in lag until n) s += onset[i] * onset[i - lag]
            ac[lag] = s / (n - lag)
        }
        var best = -1
        var bestV = Double.NEGATIVE_INFINITY
        for (lag in minLag..maxLag) {
            if (ac[lag] > bestV) { bestV = ac[lag]; best = lag }
        }
        if (best < 0 || bestV <= 0) return null
        // Interpolación parabólica para precisión sub-ventana
        val y0 = ac[best - 1]; val y1 = ac[best]; val y2 = ac[best + 1]
        val denom = y0 - 2 * y1 + y2
        val shift = if (denom != 0.0) (0.5 * (y0 - y2) / denom).coerceIn(-0.5, 0.5) else 0.0
        val bpm = 60.0 * envRate / (best + shift)
        return Math.round(bpm * 10) / 10.0
    }
}

/** Tempo marcado a mano: promedio de los últimos intervalos. */
class TapTempo {
    private val taps = ArrayDeque<Long>()

    /** Registra un toque (ms). Devuelve BPM cuando hay al menos 3 toques. */
    fun tap(nowMs: Long): Double? {
        if (taps.isNotEmpty() && nowMs - taps.last() > 2000) taps.clear()
        taps.addLast(nowMs)
        while (taps.size > 8) taps.removeFirst()
        if (taps.size < 3) return null
        val avg = (taps.last() - taps.first()).toDouble() / (taps.size - 1)
        return Math.round(60000.0 / avg * 10) / 10.0
    }
}
