package app.djlatino.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.djlatino.ui.theme.Dj
import app.djlatino.ui.theme.DjRadius
import app.djlatino.ui.theme.DjType

@Composable
fun LibraryOverlay(
    vm: DjViewModel,
    deck: Int,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onOpenFile: () -> Unit,
) {
    val c = Dj.colors
    val deckName = if (deck == 0) "A" else "B"
    val deckCol = if (deck == 0) c.deckA else c.deckB
    var query by remember { mutableStateOf("") }
    val filtered = remember(vm.tracks, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) vm.tracks
        else vm.tracks.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(c.scrim)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.libraryFor = null },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.82f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(DjRadius.lg))
                .background(c.surface2)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Cargar en plato $deckName", style = DjType.heading, color = deckCol, modifier = Modifier.weight(1f))
                SmallButton("Abrir archivo…") { onOpenFile() }
                SmallButton("Cerrar") { vm.libraryFor = null }
            }
            if (!hasPermission) {
                Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Para ver tus canciones, la app necesita permiso para leer tu música.",
                        style = DjType.body, color = c.text,
                    )
                    Text(
                        "También puedes usar «Abrir archivo…» sin dar permiso.",
                        style = DjType.caption, color = c.textMuted, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
                    )
                    SmallButton("Dar permiso") { onRequestPermission() }
                }
                return@Column
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Buscar canción o artista") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = c.text, unfocusedTextColor = c.text,
                    focusedBorderColor = deckCol, unfocusedBorderColor = c.borderInput,
                    cursorColor = deckCol,
                ),
            )
            when {
                vm.libraryLoading -> Text("Buscando canciones…", style = DjType.body, color = c.textMuted)
                vm.tracks.isEmpty() -> Text(
                    "No se encontraron canciones en el teléfono. Copia MP3 a la carpeta Música o usa «Abrir archivo…».",
                    style = DjType.body, color = c.textMuted,
                )
                filtered.isEmpty() -> Text("Sin resultados para «$query»", style = DjType.body, color = c.textMuted)
                else -> LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                    items(filtered, key = { it.uri.toString() }) { t ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .heightIn(min = 52.dp)
                                .clickable(role = Role.Button) { vm.loadTrack(deck, t.uri, t.title, t.artist) }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(t.title, style = DjType.body, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(t.artist, style = DjType.caption, color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            val s = (t.durationMs / 1000).toInt()
                            Text("%d:%02d".format(s / 60, s % 60), style = DjType.caption, color = c.textMuted)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallButton(text: String, onClick: () -> Unit) {
    val c = Dj.colors
    Text(
        text, style = DjType.label, color = c.onAccent,
        modifier = Modifier
            .clip(RoundedCornerShape(DjRadius.md))
            .background(c.accent)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
    )
}
