package app.djlatino.audio

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import app.djlatino.engine.PcmSource
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.ShortBuffer
import java.nio.channels.FileChannel
import java.util.UUID

/** PCM 16 bits estéreo en un archivo de caché mapeado en memoria: no ocupa RAM aunque la canción sea larga. */
class MappedPcmSource(
    val file: File,
    private val buf: ShortBuffer,
    override val frames: Int,
    override val sampleRate: Int,
) : PcmSource {
    override fun sample(frame: Int, ch: Int): Float = buf.get(frame * 2 + ch) / 32768f
}

class DecodeException(msg: String) : Exception(msg)

object Decoder {
    /**
     * Decodifica cualquier audio que Android soporte (MP3, AAC/M4A, FLAC, WAV, OGG, OPUS)
     * a PCM estéreo 16 bits en [cacheDir]. [onProgress] recibe 0..1.
     */
    fun decode(context: Context, uri: Uri, cacheDir: File, onProgress: (Float) -> Unit): MappedPcmSource {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
        } catch (e: Exception) {
            extractor.release()
            throw DecodeException("No se pudo abrir el archivo")
        }
        var trackIndex = -1
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) { trackIndex = i; break }
        }
        if (trackIndex < 0) { extractor.release(); throw DecodeException("El archivo no tiene audio") }
        extractor.selectTrack(trackIndex)
        val inFormat = extractor.getTrackFormat(trackIndex)
        val mime = inFormat.getString(MediaFormat.KEY_MIME)!!
        val durationUs = if (inFormat.containsKey(MediaFormat.KEY_DURATION)) inFormat.getLong(MediaFormat.KEY_DURATION) else 0L
        var sampleRate = inFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = inFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var floatPcm = false

        val codec = try {
            MediaCodec.createDecoderByType(mime).also { it.configure(inFormat, null, null, 0); it.start() }
        } catch (e: Exception) {
            extractor.release()
            throw DecodeException("Formato no soportado: $mime")
        }

        cacheDir.mkdirs()
        val outFile = File(cacheDir, "pcm_${UUID.randomUUID()}.raw")
        val out = BufferedOutputStream(FileOutputStream(outFile), 1 shl 17)
        var conv = ByteBuffer.allocate(1 shl 16).order(ByteOrder.LITTLE_ENDIAN)
        var totalFrames = 0L
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var lastProgress = -1

        try {
            while (!outputDone) {
                if (Thread.currentThread().isInterrupted) throw InterruptedException()
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)!!
                        val n = extractor.readSampleData(inBuf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, n, extractor.sampleTime, 0)
                            if (durationUs > 0) {
                                val p = (extractor.sampleTime * 100 / durationUs).toInt()
                                if (p != lastProgress) { lastProgress = p; onProgress(p / 100f) }
                            }
                            extractor.advance()
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        floatPcm = f.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    }
                    outIdx >= 0 -> {
                        val ob = codec.getOutputBuffer(outIdx)
                        if (ob != null && info.size > 0) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val bytesPerSample = if (floatPcm) 4 else 2
                            val frameCount = info.size / (bytesPerSample * channels)
                            val need = frameCount * 4
                            if (conv.capacity() < need) conv = ByteBuffer.allocate(need).order(ByteOrder.LITTLE_ENDIAN)
                            conv.clear()
                            val src = ob.slice().order(ByteOrder.nativeOrder())
                            if (floatPcm) {
                                val fb = src.asFloatBuffer()
                                for (i in 0 until frameCount) {
                                    val l = fb.get(i * channels)
                                    val r = if (channels > 1) fb.get(i * channels + 1) else l
                                    conv.putShort((l.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                                    conv.putShort((r.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                                }
                            } else {
                                val sb = src.asShortBuffer()
                                for (i in 0 until frameCount) {
                                    val l = sb.get(i * channels)
                                    val r = if (channels > 1) sb.get(i * channels + 1) else l
                                    conv.putShort(l)
                                    conv.putShort(r)
                                }
                            }
                            out.write(conv.array(), 0, need)
                            totalFrames += frameCount
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    }
                }
            }
        } catch (e: Exception) {
            out.close(); outFile.delete()
            if (e is InterruptedException) throw e
            throw DecodeException("Error al decodificar: ${e.message}")
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            extractor.release()
        }
        out.flush(); out.close()
        if (totalFrames < 2) { outFile.delete(); throw DecodeException("El archivo está vacío") }
        onProgress(1f)

        val channel = RandomAccessFile(outFile, "r").channel
        val mapped = channel.map(FileChannel.MapMode.READ_ONLY, 0, totalFrames * 4)
        channel.close() // el mapeo sigue válido tras cerrar el canal
        val shorts = mapped.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        return MappedPcmSource(outFile, shorts, totalFrames.toInt(), sampleRate)
    }
}
