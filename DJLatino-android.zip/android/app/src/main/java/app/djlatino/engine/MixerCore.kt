package app.djlatino.engine

import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tanh

/** Mezcla dos platos + sampler. Sin Android: se prueba en la JVM. */
class MixerCore(val outRate: Int) {
    val decks = arrayOf(Deck(), Deck())

    /** 0 = solo A, 1 = solo B. */
    @Volatile var crossfader = 0.5f
    @Volatile var masterGain = 0.9f

    private class Voice(val data: FloatArray, val gain: Float) { var pos = 0 }
    private val pending = ConcurrentLinkedQueue<Pair<FloatArray, Float>>()
    private val voices = ArrayList<Voice>(8)

    private var tmpA = FloatArray(0)
    private var tmpB = FloatArray(0)

    /** Lanza un sample mono a [outRate]. Seguro desde cualquier hilo. */
    fun trigger(mono: FloatArray, gain: Float = 0.8f) {
        pending.add(mono to gain)
    }

    fun render(out: FloatArray, frames: Int, nowNs: Long) {
        if (tmpA.size < frames * 2) { tmpA = FloatArray(frames * 2); tmpB = FloatArray(frames * 2) }
        decks[0].render(tmpA, frames, outRate, nowNs)
        decks[1].render(tmpB, frames, outRate, nowNs)
        // Crossfader de potencia constante
        val x = crossfader.coerceIn(0f, 1f)
        val gA = cos(x * PI / 2).toFloat() * decks[0].volume
        val gB = sin(x * PI / 2).toFloat() * decks[1].volume
        for (i in 0 until frames * 2) out[i] = tmpA[i] * gA + tmpB[i] * gB

        // Sampler (siempre audible, independiente del crossfader)
        while (true) {
            val p = pending.poll() ?: break
            if (voices.size >= 8) voices.removeAt(0)
            voices.add(Voice(p.first, p.second))
        }
        if (voices.isNotEmpty()) {
            val it = voices.iterator()
            while (it.hasNext()) {
                val v = it.next()
                var i = 0
                while (i < frames && v.pos < v.data.size) {
                    val s = v.data[v.pos] * v.gain
                    out[i * 2] += s; out[i * 2 + 1] += s
                    v.pos++; i++
                }
                if (v.pos >= v.data.size) it.remove()
            }
        }
        val g = masterGain
        for (i in 0 until frames * 2) out[i] = softClip(out[i] * g)
    }

    private fun softClip(x: Float): Float {
        val a = abs(x)
        if (a <= 0.8f) return x
        val y = 0.8f + 0.2f * tanh((a - 0.8f) / 0.2f)
        return if (x < 0) -y else y
    }
}
