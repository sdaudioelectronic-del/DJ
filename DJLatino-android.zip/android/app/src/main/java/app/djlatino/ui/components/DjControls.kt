package app.djlatino.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.djlatino.ui.theme.*
import kotlin.math.abs
import kotlin.math.roundToInt

enum class Deck { A, B }

@Composable
fun deckColor(deck: Deck?): Color = when (deck) {
    Deck.A -> Dj.colors.deckA
    Deck.B -> Dj.colors.deckB
    null -> Dj.colors.accent
}

@Composable
fun onDeckColor(deck: Deck?): Color = when (deck) {
    Deck.A -> Dj.colors.onDeckA
    Deck.B -> Dj.colors.onDeckB
    null -> Dj.colors.onAccent
}

/**
 * Perilla. value en [-1,1] si bipolar, [0,1] si no. Arrastre VERTICAL (200dp = rango completo).
 * Doble toque vuelve al valor por defecto.
 */
@Composable
fun Knob(
    label: String,
    a11yLabel: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    deck: Deck?,
    modifier: Modifier = Modifier,
    bipolar: Boolean = true,
    size: Dp = DjSize.knobMd,
    enabled: Boolean = true,
    defaultValue: Float = 0f,
    valueText: (Float) -> String = { "${(it * 100).roundToInt()} %" },
) {
    val c = Dj.colors
    val min = if (bipolar) -1f else 0f
    val default = defaultValue
    val arc = if (enabled) deckColor(deck) else c.textDisabled
    var dragging by remember { mutableStateOf(false) }
    val rangePx = with(androidx.compose.ui.platform.LocalDensity.current) { 200.dp.toPx() }
    val latest by rememberUpdatedState(value)

    Column(
        modifier
            .sizeIn(minWidth = DjSize.touchMin, minHeight = DjSize.touchMin)
            .semantics {
                contentDescription = a11yLabel
                stateDescription = valueText(value)
                progressBarRangeInfo = ProgressBarRangeInfo(value, min..1f)
                setProgress { onValueChange(it.coerceIn(min, 1f)); true }
                if (!enabled) disabled()
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(
                Modifier
                    .size(size)
                    .pointerInput(enabled) {
                        if (!enabled) return@pointerInput
                        detectTapGestures(onDoubleTap = { onValueChange(default) })
                    }
                    .pointerInput(enabled) {
                        if (!enabled) return@pointerInput
                        detectDragGestures(
                            onDragStart = { dragging = true },
                            onDragEnd = { dragging = false },
                            onDragCancel = { dragging = false },
                        ) { change, drag ->
                            change.consume()
                            val span = 1f - min
                            onValueChange((latest - drag.y / rangePx * span).coerceIn(min, 1f))
                        }
                    }
            ) {
                val stroke = 4.dp.toPx()
                val inset = stroke / 2 + 2.dp.toPx()
                val arcSize = Size(this.size.width - inset * 2, this.size.height - inset * 2)
                val tl = Offset(inset, inset)
                // pista 270°
                drawArc(c.surface3, 135f, 270f, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                val startAngle = if (bipolar) 270f else 135f
                val sweep = if (bipolar) value * 135f else value * 270f
                drawArc(arc, startAngle, sweep, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                // cuerpo
                drawCircle(c.surface2, radius = this.size.minDimension / 2 - inset - stroke)
                // indicador
                val angle = if (bipolar) value * 135f else -135f + value * 270f
                rotate(angle) {
                    drawLine(
                        c.text,
                        start = center.copy(y = center.y - this.size.minDimension * 0.12f),
                        end = center.copy(y = center.y - this.size.minDimension * 0.32f),
                        strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round,
                    )
                }
            }
            if (dragging) {
                Text(
                    valueText(value), style = DjType.micro, color = c.text,
                    modifier = Modifier
                        .offset(y = -(size / 2 + 12.dp))
                        .background(c.surface3, RoundedCornerShape(DjRadius.sm))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
        Text(label, style = DjType.micro, color = c.textMuted)
    }
}

/** Fader vertical (volumen/pitch) u horizontal (crossfader). value en [0,1]. */
@Composable
fun Fader(
    a11yLabel: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    vertical: Boolean = true,
    detentAtCenter: Boolean = false,
    valueText: (Float) -> String = { "${(it * 100).roundToInt()} %" },
) {
    val c = Dj.colors
    val latest by rememberUpdatedState(value)
    var lengthPx by remember { mutableFloatStateOf(1f) }
    Box(
        modifier
            .then(if (vertical) Modifier.width(DjSize.touchMin) else Modifier.height(DjSize.touchMin))
            .semantics {
                contentDescription = a11yLabel
                stateDescription = valueText(value)
                progressBarRangeInfo = ProgressBarRangeInfo(value, 0f..1f)
                setProgress { onValueChange(it.coerceIn(0f, 1f)); true }
            }
            .pointerInput(vertical) {
                lengthPx = if (vertical) size.height.toFloat() else size.width.toFloat()
                detectDragGestures { change, drag ->
                    change.consume()
                    val d = if (vertical) -drag.y else drag.x
                    var v = (latest + d / lengthPx).coerceIn(0f, 1f)
                    if (detentAtCenter && abs(v - 0.5f) < 0.02f) v = 0.5f
                    onValueChange(v)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val track = DjSize.faderTrackW.toPx()
            val tw = (if (vertical) DjSize.faderThumbW else DjSize.faderThumbH).toPx()
            val th = (if (vertical) DjSize.faderThumbH else DjSize.faderThumbW).toPx()
            if (vertical) {
                drawRoundRect(c.surface3, Offset(center.x - track / 2, 0f), Size(track, size.height),
                    androidx.compose.ui.geometry.CornerRadius(track / 2))
                val y = (1f - value) * (size.height - th)
                drawRoundRect(c.accent, Offset(center.x - tw / 2, y), Size(tw, th),
                    androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                drawLine(c.onAccent, Offset(center.x - tw / 2 + 4.dp.toPx(), y + th / 2),
                    Offset(center.x + tw / 2 - 4.dp.toPx(), y + th / 2), 2.dp.toPx())
            } else {
                drawRoundRect(c.surface3, Offset(0f, center.y - track / 2), Size(size.width, track),
                    androidx.compose.ui.geometry.CornerRadius(track / 2))
                val x = value * (size.width - tw)
                drawRoundRect(c.accent, Offset(x, center.y - th / 2), Size(tw, th),
                    androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                drawLine(c.onAccent, Offset(x + tw / 2, center.y - th / 2 + 4.dp.toPx()),
                    Offset(x + tw / 2, center.y + th / 2 - 4.dp.toPx()), 2.dp.toPx())
            }
        }
    }
}

enum class PadState { Empty, Assigned, Active, Locked, Loading }

/** Pad de cue, loop, sample, drop o FX. */
@Composable
fun Pad(
    label: String,
    a11yLabel: String,
    state: PadState,
    deck: Deck?,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
    onLongPress: (() -> Unit)? = null,
) {
    val c = Dj.colors
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, tween(DjMotion.press), label = "pad")
    val active = state == PadState.Active || pressed
    val bg = when {
        active -> deckColor(deck)
        state == PadState.Empty -> Color.Transparent
        else -> c.surface3
    }
    val fg = when {
        active -> onDeckColor(deck)
        state == PadState.Locked -> c.vip
        state == PadState.Empty -> c.textMuted
        else -> c.text
    }
    val shape = RoundedCornerShape(DjRadius.md)
    Box(
        modifier
            .size(DjSize.pad)
            .scale(scale)
            .clip(shape)
            .background(bg)
            .border(1.dp, if (state == PadState.Empty) c.borderInput else c.border, shape)
            .pointerInput(onLongPress) {
                detectTapGestures(
                    onPress = {
                        val press = androidx.compose.foundation.interaction.PressInteraction.Press(it)
                        source.emit(press)
                        tryAwaitRelease()
                        source.emit(androidx.compose.foundation.interaction.PressInteraction.Release(press))
                    },
                    onTap = { onTap() },
                    onLongPress = if (onLongPress != null) ({ _: Offset -> onLongPress() }) else null,
                )
            }
            .semantics(mergeDescendants = true) {
                role = Role.Button
                contentDescription = a11yLabel
                onClick { onTap(); true }
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            if (state == PadState.Locked) "🔒 $label" else label,
            style = DjType.label, color = fg, textAlign = TextAlign.Center, maxLines = 2,
        )
    }
}

enum class TransportKind { Play, Cue, Sync, Rec }

@Composable
fun TransportButton(
    kind: TransportKind,
    on: Boolean,
    deck: Deck?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val c = Dj.colors
    val fill = when {
        !enabled -> c.surface2
        on && kind == TransportKind.Rec -> c.rec
        on -> deckColor(deck)
        else -> c.surface3
    }
    val fg = when {
        !enabled -> c.textDisabled
        on && kind == TransportKind.Rec -> c.onDanger
        on -> onDeckColor(deck)
        else -> c.text
    }
    val text = when (kind) {
        TransportKind.Play -> if (on) "❚❚" else "▶"
        TransportKind.Cue -> "CUE"
        TransportKind.Sync -> "SYNC"
        TransportKind.Rec -> "REC"
    }
    val desc = when (kind) {
        TransportKind.Play -> if (on) "Pausar" else "Reproducir"
        TransportKind.Cue -> "Cue"
        TransportKind.Sync -> "Sincronizar tempo"
        TransportKind.Rec -> if (on) "Detener grabación" else "Grabar mezcla"
    }
    val sz = if (kind == TransportKind.Play) DjSize.transport else DjSize.touchMin
    Box(
        modifier
            .size(sz)
            .clip(CircleShape)
            .background(fill)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .semantics {
                contentDescription = desc
                stateDescription = if (on) "Activado" else "Desactivado"
            },
        contentAlignment = Alignment.Center,
    ) { Text(text, style = DjType.label, color = fg) }
}

/** Lector de BPM con ×2 / ÷2 / TAP. bpm null = analizando. */
@Composable
fun BpmDisplay(
    bpm: Float?,
    pitchPct: Float,
    manual: Boolean,
    deck: Deck,
    onDouble: () -> Unit,
    onHalf: () -> Unit,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = Dj.colors
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                bpm?.let { "%.1f".format(it) } ?: "—.—",
                style = DjType.bpm.copy(fontFeatureSettings = "tnum"), color = deckColor(deck),
                modifier = Modifier.semantics { contentDescription = bpm?.let { "%.1f BPM".format(it) } ?: "Analizando BPM" },
            )
            if (manual) Box(Modifier.padding(start = 4.dp).size(6.dp).background(c.warning, CircleShape))
        }
        Text("%+.1f %%".format(pitchPct), style = DjType.caption.copy(fontFeatureSettings = "tnum"), color = c.textMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(DjSpace.s1)) {
            SmallChip("÷2", "Dividir BPM entre dos", onHalf)
            SmallChip("×2", "Duplicar BPM", onDouble)
            SmallChip("TAP", "Marcar tempo tocando", onTap)
        }
    }
}

@Composable
private fun SmallChip(text: String, a11y: String, onClick: () -> Unit) {
    val c = Dj.colors
    Box(
        Modifier
            .sizeIn(minWidth = DjSize.touchMin, minHeight = DjSize.touchMin)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = a11y },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, style = DjType.micro, color = c.text,
            modifier = Modifier
                .background(c.surface3, RoundedCornerShape(DjRadius.sm))
                .padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
}

/**
 * Plato. angleDeg lo entrega el motor (posición). Centro = scratch, anillo exterior = nudge.
 */
@Composable
fun JogWheel(
    deck: Deck,
    angleDeg: Float,
    loaded: Boolean,
    positionText: String,
    onScratch: (deltaDeg: Float) -> Unit,
    onScratchEnd: () -> Unit,
    onNudge: (deltaDeg: Float) -> Unit,
    onLoadRequest: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = Dj.colors
    val ring = if (loaded) deckColor(deck) else c.border
    var touchOnRing by remember { mutableStateOf(false) }
    Box(
        modifier
            .sizeIn(minWidth = 72.dp, minHeight = 72.dp, maxWidth = 260.dp, maxHeight = 260.dp)
            .aspectRatio(1f)
            .pointerInput(loaded) {
                if (!loaded) { detectTapGestures { onLoadRequest() }; return@pointerInput }
                detectDragGestures(
                    onDragStart = { o ->
                        val r = (o - Offset(size.width / 2f, size.height / 2f)).getDistance()
                        touchOnRing = r > size.width * 0.38f
                    },
                    onDragEnd = { if (!touchOnRing) onScratchEnd() },
                    onDragCancel = { if (!touchOnRing) onScratchEnd() },
                ) { change, _ ->
                    change.consume()
                    val ctr = Offset(size.width / 2f, size.height / 2f)
                    val a0 = Math.toDegrees(kotlin.math.atan2((change.previousPosition - ctr).y.toDouble(), (change.previousPosition - ctr).x.toDouble()))
                    val a1 = Math.toDegrees(kotlin.math.atan2((change.position - ctr).y.toDouble(), (change.position - ctr).x.toDouble()))
                    var d = (a1 - a0).toFloat()
                    if (d > 180) d -= 360f
                    if (d < -180) d += 360f
                    if (touchOnRing) onNudge(d) else onScratch(d)
                }
            }
            .semantics {
                role = Role.Button
                contentDescription = if (loaded) "Plato ${deck.name}, $positionText" else "Plato ${deck.name} vacío, toca para cargar una canción"
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            drawCircle(c.surface2, r)
            drawCircle(ring, r - 2.dp.toPx(), style = Stroke(4.dp.toPx()))
            // surcos
            for (i in 1..4) drawCircle(c.surface3, r * (0.45f + i * 0.1f), style = Stroke(1.dp.toPx()))
            drawCircle(c.surface3, r * 0.3f)
            rotate(angleDeg) {
                drawLine(c.text, center, center.copy(y = center.y - r + 8.dp.toPx()), 3.dp.toPx(), StrokeCap.Round)
            }
        }
        if (!loaded) Text("Toca para\ncargar", style = DjType.caption, color = c.textMuted, textAlign = TextAlign.Center)
    }
}
