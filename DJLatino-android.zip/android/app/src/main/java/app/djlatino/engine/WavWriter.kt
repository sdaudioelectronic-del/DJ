package app.djlatino.engine

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Graba estéreo float → WAV PCM 16 bits. write() se llama desde el hilo de audio. */
class WavWriter(val file: File, private val sampleRate: Int) {
    private val out = BufferedOutputStream(FileOutputStream(file), 1 shl 16)
    private var scratch = ByteBuffer.allocate(4096).order(ByteOrder.LITTLE_ENDIAN)
    @Volatile var dataBytes = 0L
        private set

    init {
        out.write(ByteArray(44)) // cabecera provisional
    }

    fun write(interleaved: FloatArray, frames: Int) {
        val need = frames * 4
        if (scratch.capacity() < need) scratch = ByteBuffer.allocate(need).order(ByteOrder.LITTLE_ENDIAN)
        scratch.clear()
        for (i in 0 until frames * 2) {
            val v = (interleaved[i].coerceIn(-1f, 1f) * 32767f).toInt()
            scratch.putShort(v.toShort())
        }
        out.write(scratch.array(), 0, need)
        dataBytes += need
    }

    fun seconds(): Double = dataBytes / 4.0 / sampleRate

    fun close() {
        out.flush()
        out.close()
        RandomAccessFile(file, "rw").use { raf ->
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt((36 + dataBytes).toInt()); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(2)
            h.putInt(sampleRate); h.putInt(sampleRate * 4); h.putShort(4); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(dataBytes.toInt())
            raf.seek(0)
            raf.write(h.array())
        }
    }
}
