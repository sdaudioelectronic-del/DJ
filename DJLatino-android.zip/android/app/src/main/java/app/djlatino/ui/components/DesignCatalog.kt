package app.djlatino.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import app.djlatino.ui.theme.*

/** Pantalla /design (solo debug): todos los primitivos en todos sus estados. Capturarla = chequeo del sistema. */
@Composable
fun DesignCatalog() {
    val c = Dj.colors
    Column(
        Modifier.fillMaxSize().background(c.bg).verticalScroll(rememberScrollState()).padding(DjSpace.s4),
        verticalArrangement = Arrangement.spacedBy(DjSpace.s5),
    ) {
        Section("Perillas") {
            var lo by remember { mutableFloatStateOf(-0.4f) }
            var hi by remember { mutableFloatStateOf(0.6f) }
            var fx by remember { mutableFloatStateOf(0.3f) }
            Row(horizontalArrangement = Arrangement.spacedBy(DjSpace.s4)) {
                Knob("LOW", "Graves plato A", lo, { lo = it }, Deck.A)
                Knob("HI", "Agudos plato B", hi, { hi = it }, Deck.B)
                Knob("FX", "Intensidad efecto", fx, { fx = it }, null, bipolar = false)
                Knob("OFF", "Deshabilitada", 0f, {}, Deck.A, enabled = false)
            }
        }
        Section("Faders") {
            var vol by remember { mutableFloatStateOf(0.7f) }
            var xf by remember { mutableFloatStateOf(0.5f) }
            Row(horizontalArrangement = Arrangement.spacedBy(DjSpace.s5)) {
                Fader("Volumen plato A", vol, { vol = it }, Modifier.height(140.dp))
                Fader("Crossfader", xf, { xf = it }, Modifier.width(200.dp), vertical = false, detentAtCenter = true)
            }
        }
        Section("Pads") {
            Row(horizontalArrangement = Arrangement.spacedBy(DjSpace.s2)) {
                Pad("+", "Pad vacío", PadState.Empty, Deck.A, {})
                Pad("CUE 1", "Cue 1", PadState.Assigned, Deck.A, {})
                Pad("CUE 2", "Cue 2 activo", PadState.Active, Deck.A, {})
                Pad("AIR\nHORN", "Drop air horn", PadState.Active, Deck.B, {})
                Pad("VIP", "Bloqueado VIP", PadState.Locked, null, {})
            }
        }
        Section("Transporte") {
            Row(horizontalArrangement = Arrangement.spacedBy(DjSpace.s3)) {
                TransportButton(TransportKind.Play, false, Deck.A, {})
                TransportButton(TransportKind.Play, true, Deck.A, {})
                TransportButton(TransportKind.Cue, false, Deck.B, {})
                TransportButton(TransportKind.Sync, true, Deck.B, {})
                TransportButton(TransportKind.Rec, true, null, {})
                TransportButton(TransportKind.Sync, false, Deck.A, {}, enabled = false)
            }
        }
        Section("BPM") {
            Row(horizontalArrangement = Arrangement.spacedBy(DjSpace.s6)) {
                BpmDisplay(94.0f, -1.2f, false, Deck.A, {}, {}, {})
                BpmDisplay(null, 0f, false, Deck.B, {}, {}, {})
                BpmDisplay(178.5f, 2.4f, true, Deck.B, {}, {}, {})
            }
        }
        Section("Platos") {
            Row(horizontalArrangement = Arrangement.spacedBy(DjSpace.s4)) {
                JogWheel(Deck.A, 40f, true, "1:23 de 4:05", {}, {}, {}, {}, Modifier.size(160.dp))
                JogWheel(Deck.B, 0f, false, "", {}, {}, {}, {}, Modifier.size(160.dp))
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(DjSpace.s2)) {
        Text(title, style = DjType.heading, color = Dj.colors.text)
        content()
    }
}

@Preview(widthDp = 800, heightDp = 1100, backgroundColor = 0xFF0E0F12, showBackground = true)
@Composable
private fun DesignCatalogPreview() = DjTheme { DesignCatalog() }
