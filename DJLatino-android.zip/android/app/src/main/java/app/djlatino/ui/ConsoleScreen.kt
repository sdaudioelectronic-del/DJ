package app.djlatino.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import app.djlatino.ui.components.Deck
import app.djlatino.ui.components.Fader
import app.djlatino.ui.components.JogWheel
import app.djlatino.ui.components.Knob
import app.djlatino.ui.components.Pad
import app.djlatino.ui.components.PadState
import app.djlatino.ui.components.TransportButton
import app.djlatino.ui.components.TransportKind
import app.djlatino.ui.components.deckColor
import app.djlatino.ui.components.onDeckColor
import app.djlatino.ui.theme.Dj
import app.djlatino.ui.theme.DjRadius
import app.djlatino.ui.theme.DjSpace
import app.djlatino.ui.theme.DjType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun deckOf(d: Int) = if (d == 0) Deck.A else Deck.B

private fun fmtTime(sec: Double): String {
    val s = sec.toInt().coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

@Composable
fun ConsoleScreen(vm: DjViewModel) {
    val c = Dj.colors
    val context = LocalContext.current

    // Reloj de la UI: actualiza posición, platos y temporizador a la tasa de refresco.
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos { tick = it }
            for (d in 0..1) {
                val p = vm.mixer.decks[d].playing
                if (vm.decks[d].playing != p) vm.decks[d].playing = p
            }
        }
    }

    // Permisos
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            vm.refreshLibrary()
        } else {
            vm.message = "Sin permiso solo puedes abrir archivos sueltos"
        }
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.message = if (granted) "Listo: mantén pulsado MI DROP y habla" else "Sin micrófono no se pueden grabar drops"
    }
    var pickerTarget by remember { mutableStateOf(0) }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.loadTrack(pickerTarget, uri, null, null)
    }

    fun openLibrary(d: Int) {
        vm.libraryFor = d
        if (ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED) vm.refreshLibrary()
        else permLauncher.launch(audioPermission())
    }

    fun micGranted() = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    LaunchedEffect(vm.message) {
        if (vm.message != null) { delay(2800); vm.message = null }
    }

    Box(Modifier.fillMaxSize().background(c.bg)) {
        Column(Modifier.fillMaxSize()) {
            TopBar(vm, tick)
            Row(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                DeckPanel(vm, 0, tick, { openLibrary(0) }, Modifier.weight(1f).fillMaxHeight())
                MixerPanel(vm, Modifier.width(212.dp).fillMaxHeight())
                DeckPanel(vm, 1, tick, { openLibrary(1) }, Modifier.weight(1f).fillMaxHeight())
            }
            BottomBar(vm, micGranted = { micGranted() }, requestMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) })
        }

        vm.libraryFor?.let { d ->
            LibraryOverlay(
                vm = vm, deck = d,
                hasPermission = ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED,
                onRequestPermission = { permLauncher.launch(audioPermission()) },
                onOpenFile = { pickerTarget = d; fileLauncher.launch(arrayOf("audio/*")) },
            )
        }

        vm.message?.let { msg ->
            Text(
                msg, style = DjType.body, color = c.text,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 72.dp)
                    .background(c.surface3, RoundedCornerShape(DjRadius.md))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            )
        }
    }
}

@Composable
private fun TopBar(vm: DjViewModel, tick: Long) {
    val c = Dj.colors
    Row(
        Modifier.fillMaxWidth().height(36.dp).background(c.surface).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("DJ LATINO", style = DjType.label, color = c.textMuted)
        if (vm.micRecording) Text("🎙 Grabando drop…", style = DjType.caption, color = c.success)
        Spacer(Modifier.weight(1f))
        val rec = vm.recording
        @Suppress("UNUSED_VARIABLE") val t = tick
        Text(
            if (rec) "● REC ${fmtTime(vm.recordingSeconds())}" else "● GRABAR MEZCLA",
            style = DjType.label,
            color = if (rec) c.onDanger else c.text,
            modifier = Modifier
                .clip(RoundedCornerShape(DjRadius.full))
                .background(if (rec) c.rec else c.surface3)
                .clickable(role = Role.Button) { vm.toggleRecording() }
                .padding(horizontal = 12.dp, vertical = 5.dp),
        )
    }
}

@Composable
private fun DeckPanel(vm: DjViewModel, d: Int, tick: Long, onLoad: () -> Unit, modifier: Modifier) {
    val c = Dj.colors
    val ui = vm.decks[d]
    val engineDeck = vm.mixer.decks[d]
    val deck = deckOf(d)
    @Suppress("UNUSED_VARIABLE") val t = tick
    val loaded = engineDeck.source != null && ui.loadProgress == null
    val src = engineDeck.source
    val posFrames = engineDeck.position
    val totalFrames = src?.frames ?: 1
    val rate = src?.sampleRate ?: 44100
    val posSec = posFrames / rate
    var bpmMenu by remember { mutableStateOf(false) }

    Column(
        modifier
            .clip(RoundedCornerShape(DjRadius.lg))
            .background(c.surface)
            .border(1.dp, c.border, RoundedCornerShape(DjRadius.lg))
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        // Cabecera: plato, canción, género, BPM
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                Modifier.size(22.dp).background(deckColor(deck), RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center,
            ) { Text(deck.name, style = DjType.label, color = onDeckColor(deck)) }
            Column(
                Modifier.weight(1f).clickable(role = Role.Button, onClick = onLoad)
                    .semantics { contentDescription = "Cargar canción en plato ${deck.name}" },
            ) {
                Text(
                    ui.title ?: "Toca para cargar", style = DjType.label, color = if (ui.title == null) c.textMuted else c.text,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                val lp = ui.loadProgress
                Text(
                    when {
                        lp != null -> "Cargando… ${(lp * 100).toInt()} %"
                        ui.title != null -> "${ui.artist}  ·  ${fmtTime(posSec)} / ${fmtTime(totalFrames.toDouble() / rate)}"
                        else -> "Biblioteca o archivo"
                    },
                    style = DjType.caption, color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                ui.genre.label, style = DjType.micro, color = c.text,
                modifier = Modifier
                    .clip(RoundedCornerShape(DjRadius.full))
                    .background(c.surface3)
                    .border(1.5.dp, deckColor(deck), RoundedCornerShape(DjRadius.full))
                    .clickable(role = Role.Button) { vm.cycleGenre(d) }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .semantics { contentDescription = "Género ${ui.genre.label}, toca para cambiar" },
            )
            Box {
                Column(
                    Modifier
                        .pointerInput(d) {
                            detectTapGestures(onTap = { vm.tapBpm(d) }, onLongPress = { bpmMenu = true })
                        }
                        .semantics { role = Role.Button; contentDescription = "BPM. Toca al ritmo para marcarlo, mantén para opciones" },
                    horizontalAlignment = Alignment.End,
                ) {
                    val shown = ui.bpm?.let { it * engineDeck.tempo }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (ui.bpmManual) Box(Modifier.padding(end = 3.dp).size(5.dp).background(c.warning, CircleShape))
                        Text(
                            shown?.let { "%.1f".format(it) } ?: if (ui.peaks != null) "—" else "",
                            style = DjType.heading.copy(fontFeatureSettings = "tnum"), color = deckColor(deck),
                        )
                    }
                    Text(
                        "%+.1f %%".format((engineDeck.tempo - 1) * 100) + if (ui.synced) " SYNC" else "",
                        style = DjType.micro.copy(fontFeatureSettings = "tnum"), color = c.textMuted,
                    )
                }
                DropdownMenu(expanded = bpmMenu, onDismissRequest = { bpmMenu = false }) {
                    DropdownMenuItem(text = { Text("÷2  (mitad)") }, onClick = { vm.halveBpm(d); bpmMenu = false })
                    DropdownMenuItem(text = { Text("×2  (doble)") }, onClick = { vm.doubleBpm(d); bpmMenu = false })
                    DropdownMenuItem(text = { Text("Recalcular") }, onClick = { vm.redetect(d); bpmMenu = false })
                }
            }
        }

        // Forma de onda
        Waveform(
            peaks = ui.peaks, progress = ui.loadProgress, fraction = (posFrames / totalFrames).toFloat(),
            cues = ui.hotCues.mapNotNull { it?.let { p -> (p / totalFrames).toFloat() } },
            deck = deck, onSeek = { vm.seekFraction(d, it) },
            modifier = Modifier.fillMaxWidth().height(26.dp),
        )

        // Transporte | plato | pitch
        Row(Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(
                Modifier.width(56.dp).fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                TransportButton(TransportKind.Sync, ui.synced, deck, { vm.sync(d) }, enabled = loaded)
                TransportButton(TransportKind.Cue, false, deck, { vm.cue(d) }, enabled = loaded)
                TransportButton(TransportKind.Play, ui.playing, deck, { vm.togglePlay(d) })
            }
            Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                JogWheel(
                    deck = deck,
                    angleDeg = ((posSec / 1.8) * 360.0 % 360.0).toFloat(),
                    loaded = loaded,
                    positionText = "${fmtTime(posSec)} de ${fmtTime(totalFrames.toDouble() / rate)}",
                    onScratch = { vm.scratch(d, it) },
                    onScratchEnd = { vm.scratchEnd(d) },
                    onNudge = { vm.nudgeRing(d, it) },
                    onLoadRequest = onLoad,
                    modifier = Modifier.fillMaxHeight(),
                )
            }
            Column(
                Modifier.width(52.dp).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                NudgeButton("+", "Acelerar momentáneamente") { pressed -> vm.holdNudge(d, if (pressed) 0.04 else 0.0) }
                Fader(
                    "Pitch plato ${deck.name}", ui.pitchFader, { vm.setPitch(d, it) },
                    Modifier.weight(1f), vertical = true, detentAtCenter = true,
                    valueText = { "%+.1f %%".format((it - 0.5f) * 16f) },
                )
                NudgeButton("−", "Frenar momentáneamente") { pressed -> vm.holdNudge(d, if (pressed) -0.04 else 0.0) }
            }
        }
    }
}

@Composable
private fun NudgeButton(label: String, a11y: String, onPressChange: (Boolean) -> Unit) {
    val c = Dj.colors
    Box(
        Modifier
            .size(40.dp)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    onPressChange(true)
                    tryAwaitRelease()
                    onPressChange(false)
                })
            }
            .semantics { role = Role.Button; contentDescription = a11y },
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(30.dp).background(c.surface3, RoundedCornerShape(DjRadius.sm)), contentAlignment = Alignment.Center) {
            Text(label, style = DjType.label, color = c.text)
        }
    }
}

@Composable
private fun Waveform(
    peaks: FloatArray?, progress: Float?, fraction: Float, cues: List<Float>, deck: Deck,
    onSeek: (Float) -> Unit, modifier: Modifier,
) {
    val c = Dj.colors
    val col = deckColor(deck)
    Canvas(
        modifier
            .clip(RoundedCornerShape(DjRadius.sm))
            .background(c.surface2)
            .pointerInput(peaks != null) {
                if (peaks != null) detectTapGestures { o -> onSeek(o.x / size.width) }
            }
            .semantics { contentDescription = "Forma de onda, toca para saltar" },
    ) {
        val w = size.width
        val h = size.height
        if (progress != null) {
            drawRect(c.surface3, size = Size(w * progress, h))
            return@Canvas
        }
        if (peaks == null) return@Canvas
        val bars = (w / 3f).toInt().coerceAtLeast(1)
        for (i in 0 until bars) {
            val p = peaks[(i * peaks.size / bars).coerceAtMost(peaks.size - 1)]
            val bh = (p * h * 0.9f).coerceAtLeast(1f)
            val x = i * 3f
            drawRect(col.copy(alpha = if (x / w < fraction) 0.45f else 1f), Offset(x, (h - bh) / 2), Size(2f, bh))
        }
        for (cue in cues) drawRect(c.warning, Offset(cue * w, 0f), Size(2f, h))
        drawRect(c.text, Offset(fraction * w - 1f, 0f), Size(2f, h))
    }
}

@Composable
private fun MixerPanel(vm: DjViewModel, modifier: Modifier) {
    val c = Dj.colors
    val a = vm.decks[0]
    val b = vm.decks[1]
    Column(
        modifier
            .clip(RoundedCornerShape(DjRadius.lg))
            .background(c.surface)
            .border(1.dp, c.border, RoundedCornerShape(DjRadius.lg))
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.weight(1f).fillMaxWidth()) {
            Fader("Volumen plato A", a.volume, { vm.setVolume(0, it) }, Modifier.fillMaxHeight())
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                KnobRow("HI", a.eqHigh, { vm.setEqHigh(0, it) }, b.eqHigh, { vm.setEqHigh(1, it) }, "Agudos")
                KnobRow("MID", a.eqMid, { vm.setEqMid(0, it) }, b.eqMid, { vm.setEqMid(1, it) }, "Medios")
                KnobRow("LOW", a.eqLow, { vm.setEqLow(0, it) }, b.eqLow, { vm.setEqLow(1, it) }, "Graves")
                KnobRow("FILT", a.filter, { vm.setFilter(0, it) }, b.filter, { vm.setFilter(1, it) }, "Filtro")
            }
            Fader("Volumen plato B", b.volume, { vm.setVolume(1, it) }, Modifier.fillMaxHeight())
        }
        Fader(
            "Crossfader", vm.crossfader, { vm.setCrossfader(it) },
            Modifier.fillMaxWidth(), vertical = false, detentAtCenter = true,
            valueText = { "${(it * 100).toInt()} % hacia B" },
        )
    }
}

@Composable
private fun KnobRow(
    label: String, va: Float, onA: (Float) -> Unit, vb: Float, onB: (Float) -> Unit, a11y: String,
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Knob(label, "$a11y plato A", va, onA, Deck.A, size = 34.dp, valueText = { knobText(label, it) })
        Knob(label, "$a11y plato B", vb, onB, Deck.B, size = 34.dp, valueText = { knobText(label, it) })
    }
}

private fun knobText(label: String, v: Float): String =
    if (label == "FILT") when { v < -0.03f -> "LPF ${(-v * 100).toInt()} %"; v > 0.03f -> "HPF ${(v * 100).toInt()} %"; else -> "Abierto" }
    else "%+.0f dB".format(if (v < 0) v * 26 else v * 6)

private enum class Tab(val label: String) { PADS("PADS"), LOOP("LOOP"), CUES("CUES"), FX("FX") }

@Composable
private fun BottomBar(vm: DjViewModel, micGranted: () -> Boolean, requestMic: () -> Unit) {
    val c = Dj.colors
    var tab by remember { mutableStateOf(Tab.PADS) }
    Row(
        Modifier.fillMaxWidth().height(60.dp).background(c.surface).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        for (t in Tab.entries) {
            val on = t == tab
            Text(
                t.label, style = DjType.label, color = if (on) c.text else c.textMuted,
                modifier = Modifier
                    .clip(RoundedCornerShape(DjRadius.md))
                    .background(if (on) c.surface3 else c.surface)
                    .clickable(role = Role.Tab) { tab = t }
                    .padding(horizontal = 10.dp, vertical = 12.dp),
            )
        }
        Spacer(Modifier.width(4.dp))
        LazyRow(
            Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            when (tab) {
                Tab.PADS -> {
                    item { DropPad(vm, micGranted, requestMic) }
                    for (s in PadSound.entries) item { Pad(s.label, "Sonido ${s.label}", PadState.Assigned, Deck.B, { vm.playPad(s) }) }
                    for (d in 0..1) {
                        val dk = deckOf(d)
                        item { Pad("SPIN\n${dk.name}", "Spinback plato ${dk.name}", PadState.Assigned, dk, { vm.spinback(d) }) }
                        item { Pad("FRENO\n${dk.name}", "Freno plato ${dk.name}", PadState.Assigned, dk, { vm.brake(d) }) }
                    }
                }
                Tab.LOOP -> for (d in 0..1) {
                    val dk = deckOf(d)
                    for (beats in listOf(1.0, 2.0, 4.0, 8.0)) item {
                        val active = vm.decks[d].loopBeats == beats
                        Pad(
                            "${dk.name}·${beats.toInt()}", "Loop de ${beats.toInt()} tiempos plato ${dk.name}",
                            if (active) PadState.Active else PadState.Assigned, dk, { vm.loop(d, beats) },
                        )
                    }
                }
                Tab.CUES -> for (d in 0..1) {
                    val dk = deckOf(d)
                    for (slot in 0 until 4) item {
                        val set = vm.decks[d].hotCues[slot] != null
                        Pad(
                            if (set) "${dk.name}${slot + 1}" else "+",
                            if (set) "Cue ${slot + 1} plato ${dk.name}, mantén para borrar" else "Guardar cue ${slot + 1} plato ${dk.name}",
                            if (set) PadState.Assigned else PadState.Empty, dk,
                            { vm.hotCue(d, slot) }, onLongPress = { vm.clearHotCue(d, slot) },
                        )
                    }
                }
                Tab.FX -> for (d in 0..1) {
                    val dk = deckOf(d)
                    item {
                        Pad(
                            "ECO\n${dk.name}", "Eco plato ${dk.name}",
                            if (vm.decks[d].echo) PadState.Active else PadState.Assigned, dk, { vm.toggleEcho(d) },
                        )
                    }
                }
            }
        }
    }
}

/** Toca = lanzar tu drop. Mantén pulsado = grabarlo con el micrófono. */
@Composable
private fun DropPad(vm: DjViewModel, micGranted: () -> Boolean, requestMic: () -> Unit) {
    val c = Dj.colors
    val scope = rememberCoroutineScope()
    var pressStart by remember { mutableLongStateOf(0L) }
    val rec = vm.micRecording
    Box(
        Modifier
            .size(width = 72.dp, height = 56.dp)
            .clip(RoundedCornerShape(DjRadius.md))
            .background(if (rec) c.rec else if (vm.hasDrop) c.surface3 else c.surface)
            .border(1.dp, if (vm.hasDrop) c.border else c.borderInput, RoundedCornerShape(DjRadius.md))
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressStart = System.currentTimeMillis()
                        var started = false
                        val job = scope.launch {
                            delay(350)
                            if (micGranted()) started = vm.startDropRecording() else requestMic()
                        }
                        tryAwaitRelease()
                        job.cancel()
                        if (started) vm.stopDropRecording()
                    },
                    onTap = {
                        if (System.currentTimeMillis() - pressStart < 350) {
                            if (vm.hasDrop) {
                                vm.playDrop()
                            } else {
                                vm.message = "Mantén pulsado MI DROP y di tu nombre de DJ"
                            }
                        }
                    },
                )
            }
            .semantics { role = Role.Button; contentDescription = "Mi drop. Toca para lanzar, mantén pulsado para grabar" },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            when { rec -> "🎙 SUELTA\nPARA GUARDAR"; vm.hasDrop -> "MI DROP"; else -> "MI DROP\n(mantén)" },
            style = DjType.micro, color = if (rec) c.onDanger else c.text,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}
