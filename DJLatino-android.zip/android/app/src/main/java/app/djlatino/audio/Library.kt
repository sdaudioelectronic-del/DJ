package app.djlatino.audio

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

data class TrackItem(val uri: Uri, val title: String, val artist: String, val durationMs: Long)

object Library {
    /** Canciones del teléfono (MediaStore). Requiere READ_MEDIA_AUDIO / READ_EXTERNAL_STORAGE. */
    fun query(context: Context): List<TrackItem> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
        )
        val result = ArrayList<TrackItem>()
        context.contentResolver.query(
            collection, projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 20000",
            null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC",
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val tCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val aCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val dCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val artist = c.getString(aCol)
                result.add(
                    TrackItem(
                        uri = ContentUris.withAppendedId(collection, c.getLong(idCol)),
                        title = c.getString(tCol) ?: "Sin título",
                        artist = if (artist == null || artist == "<unknown>") "Artista desconocido" else artist,
                        durationMs = c.getLong(dCol),
                    )
                )
            }
        }
        return result
    }

    /** Nombre visible de un archivo elegido con el selector del sistema. */
    fun displayName(context: Context, uri: Uri): String {
        val name = try {
            context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (e: Exception) { null }
        return name?.substringBeforeLast('.') ?: "Archivo"
    }

    /** Copia la grabación a Música/DJ Latino para que aparezca en el reproductor. Devuelve dónde quedó. */
    fun publishRecording(context: Context, wav: File): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, wav.name)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/DJ Latino")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: return wav.absolutePath
            resolver.openOutputStream(uri)?.use { os -> wav.inputStream().use { it.copyTo(os) } }
            values.clear()
            values.put(MediaStore.Audio.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            wav.delete()
            "Música/DJ Latino/${wav.name}"
        } else {
            MediaScannerConnection.scanFile(context, arrayOf(wav.absolutePath), arrayOf("audio/wav"), null)
            wav.absolutePath
        }
    }
}
