package app.djlatino.engine

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File
import kotlin.math.*
import kotlin.random.Random

private var fails = 0
private fun check(name: String, ok: Boolean, detail: String = "") { println((if (ok) "OK    " else "FALLA ") + name + " " + detail); if (!ok) fails++ }

// Pista sintética: bombo en cada tiempo + caja en patrón dembow + hi-hat + ruido, opcional tempo vivo (deriva)
private fun synthTrack(bpm: Double, seconds: Double, fs: Int, dembow: Boolean, drift: Double = 0.0, seed: Int = 1): FloatArray {
    val n = (seconds * fs).toInt(); val out = FloatArray(n * 2); val rnd = Random(seed)
    var t = 0.0; var beat = 0
    while (t < seconds) {
        val local = bpm * (1 + drift * sin(2 * PI * t / 20))
        val beatLen = 60.0 / local
        fun hit(at: Double, f: Double, dec: Double, amp: Double, noise: Boolean) {
            val s0 = (at * fs).toInt(); var ph = 0.0
            for (i in 0 until (0.25 * fs).toInt()) { val k = s0 + i; if (k >= n) break
                val tt = i.toDouble() / fs; ph += (if (noise) 0.0 else f * (1 + 2 * exp(-tt * 30))) / fs
                val v = (if (noise) rnd.nextDouble() * 2 - 1 else sin(2 * PI * ph)) * exp(-tt * dec) * amp
                out[k * 2] += v.toFloat(); out[k * 2 + 1] += v.toFloat() } }
        hit(t, 55.0, 12.0, 0.8, false)                                  // bombo
        if (dembow) { hit(t + beatLen * 0.75, 0.0, 25.0, 0.35, true); if (beat % 2 == 1) hit(t + beatLen * 0.5, 0.0, 25.0, 0.4, true) }
        else hit(t + beatLen * 0.5, 0.0, 40.0, 0.2, true)               // contratiempo
        t += beatLen; beat++
    }
    for (i in out.indices) out[i] += ((rnd.nextDouble() * 2 - 1) * 0.02).toFloat()
    return out
}

fun runAll(): Int {
    fails = 0
    val fs = 44100
    // --- BPM ---
    data class Case(val bpm: Double, val genre: Genre, val dembow: Boolean, val drift: Double)
    for (c in listOf(Case(94.0, Genre.REGGAETON, true, 0.0), Case(98.5, Genre.AUTO, true, 0.0),
                     Case(148.0, Genre.MERENGUE, false, 0.0), Case(182.0, Genre.SALSA, false, 0.01),
                     Case(126.0, Genre.AUTO, false, 0.0))) {
        val src = FloatArraySource(synthTrack(c.bpm, 40.0, fs, c.dembow, c.drift), fs)
        val a = Analyzer.analyze(src)
        val b = BpmDetector.detect(a.env, a.envRate, c.genre)
        check("BPM ${c.bpm} ${c.genre}", b != null && abs(b - c.bpm) / c.bpm < 0.015, "→ $b")
    }
    check("BPM pista corta → null", BpmDetector.detect(FloatArray(100), 172.0, Genre.AUTO) == null)
    val tap = TapTempo(); var tb: Double? = null
    for (i in 0 until 5) tb = tap.tap(1000L + i * 638L)
    check("Tap tempo ~94", tb != null && abs(tb!! - 94.0) < 0.5, "→ $tb")

    // --- Deck ---
    val ramp = FloatArray(fs * 2 * 4) { (it / 2 % 1000) / 1000f }  // 4 s
    val deck = Deck(); deck.load(FloatArraySource(ramp, fs))
    val buf = FloatArray(512 * 2)
    deck.playing = true
    deck.render(buf, 512, fs, 0L)
    check("Deck tempo 1 copia muestras", abs(buf[200 * 2] - ramp[200 * 2]) < 1e-4, "${buf[400]} vs ${ramp[400]}")
    check("Deck avanza posición", abs(deck.position - 512) < 1e-6, "${deck.position}")
    deck.tempo = 1.08; val p0 = deck.position; deck.render(buf, 512, fs, 0L)
    check("Tempo +8% avanza 1.08x", abs(deck.position - p0 - 512 * 1.08) < 1e-6)
    // Fuente a 48k reproducida a 44.1k
    val d48 = Deck(); d48.load(FloatArraySource(FloatArray(48000 * 2), 48000)); d48.playing = true; d48.render(buf, 441, fs, 0L)
    check("Frecuencia de muestreo distinta", abs(d48.position - 480) < 1e-6, "${d48.position}")
    // Loop
    deck.tempo = 1.0; deck.bpm = 120.0; deck.loopRequestBeats = 1.0; deck.render(buf, 512, fs, 0L)
    check("Loop activo", deck.loopActive)
    val start = deck.position - 512
    repeat(200) { deck.render(buf, 512, fs, 0L) }
    check("Loop se mantiene dentro de 1 tiempo", deck.position >= start - 1 && deck.position <= start + 0.5 * fs + 1, "pos=${deck.position} start=$start")
    deck.loopRequestBeats = -1.0; deck.render(buf, 512, fs, 0L); check("Salir del loop", !deck.loopActive)
    // Fin de pista
    deck.seekRequest = (ramp.size / 2 - 100).toDouble(); deck.render(buf, 512, fs, 0L)
    check("Para al final de la pista", !deck.playing)
    // Spinback y freno terminan en pausa
    deck.seekRequest = fs * 2.0; deck.playing = true; deck.effectRequest = 1
    repeat(200) { deck.render(buf, 512, fs, 0L) }
    check("Spinback retrocede y pausa", !deck.playing && deck.position < fs * 2.0, "pos=${deck.position}")
    deck.playing = true; deck.effectRequest = 2; val pb = deck.position
    repeat(200) { deck.render(buf, 512, fs, 0L) }
    check("Freno avanza menos que 1.3 s y pausa", !deck.playing && deck.position - pb < 1.3 * fs && deck.position > pb)
    // Scratch: velocidad -1 caduca a los 60 ms
    deck.playing = false; deck.seekRequest = fs * 2.0; deck.scratching = true; deck.scratchSpeed = -1.0; deck.scratchStampNs = 0
    deck.render(buf, 512, fs, 1_000_000L); check("Scratch hacia atrás", deck.position < fs * 2.0)
    // Silencio con plato vacío
    val empty = Deck(); val z = FloatArray(1024) { 1f }; empty.render(z, 512, fs, 0); check("Plato vacío = silencio", z.all { it == 0f })

    // --- EQ / filtro: kill de graves atenúa 60 Hz ---
    fun rms(f: Double, setup: (Deck) -> Unit): Double {
        val sine = FloatArray(fs * 2) { val i = it / 2; (0.5 * sin(2 * PI * f * i / fs)).toFloat() }
        val d = Deck(); d.load(FloatArraySource(sine, fs)); setup(d); d.playing = true
        var s = 0.0; var cnt = 0
        repeat(60) { k -> d.render(buf, 512, fs, 0); if (k > 10) for (x in buf) { s += x * x; cnt++ } }
        return sqrt(s / cnt)
    }
    val flat = rms(60.0) {}; val kill = rms(60.0) { it.eqLow = -1f }
    check("EQ low kill a 60 Hz", 20 * log10(kill / flat) < -18, "%.1f dB".format(20 * log10(kill / flat)))
    val hiFlat = rms(8000.0) {}; val lpf = rms(8000.0) { it.filter = -0.8f }
    check("Filtro LPF corta 8 kHz", 20 * log10(lpf / hiFlat) < -20, "%.1f dB".format(20 * log10(lpf / hiFlat)))
    check("Mid +6 dB a 1 kHz", abs(20 * log10(rms(1000.0) { it.eqMid = 1f } / rms(1000.0) {}) - 6) < 0.6)

    // --- Eco produce cola ---
    val click = FloatArray(fs * 2 * 2); click[0] = 1f; click[1] = 1f
    val de = Deck(); de.load(FloatArraySource(click, fs)); de.echoOn = true; de.playing = true
    var tail = 0f; repeat(100) { de.render(buf, 512, fs, 0); if (it > 40) for (x in buf) tail = max(tail, abs(x)) }
    check("Eco genera repeticiones", tail > 0.05f, "$tail")

    // --- Mixer ---
    val mix = MixerCore(fs)
    mix.decks[0].load(FloatArraySource(FloatArray(fs * 2) { 0.5f }, fs)); mix.decks[0].playing = true
    mix.decks[1].load(FloatArraySource(FloatArray(fs * 2) { -0.5f }, fs)); mix.decks[1].playing = true
    val o = FloatArray(1024)
    mix.crossfader = 0f; mix.render(o, 512, 0); check("Crossfader en A", o[100] > 0.4f, "${o[100]}")
    mix.crossfader = 1f; mix.render(o, 512, 0); check("Crossfader en B", o[100] < -0.4f, "${o[100]}")
    mix.crossfader = 0.5f; mix.render(o, 512, 0); check("Crossfader centro cancela", abs(o[100]) < 0.01f, "${o[100]}")
    mix.decks[0].playing = false; mix.decks[1].playing = false
    mix.trigger(FloatArray(300) { 2f }, 1f); mix.render(o, 512, 0)
    check("Sampler suena y soft clip < 1", o[10] > 0.8f && o[10] <= 1f && o[700] == 0f, "${o[10]} ${o[700]}")
    // Sintetizador
    for ((name, s) in listOf("airHorn" to Synth.airHorn(fs), "siren" to Synth.siren(fs), "laser" to Synth.laser(fs), "boom" to Synth.boom(fs)))
        check("Synth $name en rango", s.isNotEmpty() && s.all { it.isFinite() && abs(it) <= 1f } && s.maxOf { abs(it) } > 0.2f)
    // Rendimiento: 1 s de audio con 2 platos + EQ + eco
    mix.decks[0].playing = true; mix.decks[1].playing = true; mix.decks[0].eqLow = -0.5f; mix.decks[1].echoOn = true; mix.decks[1].filter = 0.4f
    val big = FloatArray(512); val t0 = System.nanoTime()
    repeat(fs / 256 * 10) { mix.render(big, 256, 0) }
    val ms = (System.nanoTime() - t0) / 1e6 / 10
    check("Rendimiento", ms < 200, "%.1f ms por segundo de audio".format(ms))

    // --- WAV ---
    val f = File.createTempFile("test", ".wav"); val w = WavWriter(f, fs); val sig = FloatArray(fs * 2) { sin(it / 20.0).toFloat() * 0.5f }
    w.write(sig, fs); w.close(); println("WAV escrito: ${f.length()} bytes, ${w.seconds()} s")
    println("\n$fails fallos")
    return fails
}

class EngineTest {
    @Test fun motorDeAudio() = assertEquals(0L, runAll().toLong())
}
