# DJ Latino (versión 0.1, prototipo funcional)

App de DJ para Android pensada para reguetón, salsa y merengue. Esta versión es el primer prototipo que funciona de punta a punta.

## Qué hace ya
- **Dos platos**: cargas canciones de tu teléfono (desde la biblioteca o con «Abrir archivo…») en MP3, M4A, FLAC, WAV u OGG.
- **Play, CUE y SYNC**. SYNC elige solo ×½, ×1 o ×2 para que, por ejemplo, un reguetón a 95 se pueda mezclar con un merengue a 190.
- **BPM automático por género**: toca el chip del género para cambiarlo (Auto, Reguetón, Merengue o Salsa). Si tocas el número del BPM al ritmo, lo marcas a mano; si lo mantienes pulsado, aparecen ÷2, ×2 y Recalcular.
- **Pitch** de ±8 %, botones **+ y −** para empujar el plato a mano, y **scratch** en el plato: el centro hace scratch y el anillo empuja.
- **Mezclador**: volumen por plato, ecualizador de 3 bandas (HI, MID, LOW, con kill), filtro paso bajo o paso alto (FILT) y crossfader.
- **Pads**: AIR HORN, SIRENA, LÁSER, BOMBA (sonidos generados por la app, sin licencias), **SPINBACK** y **FRENO**.
- **MI DROP**: mantén pulsado y di tu nombre de DJ. Se guarda y luego lo lanzas con un toque.
- **Loops** de 1, 2, 4 y 8 tiempos, **4 cues por plato** (mantén pulsado para borrar) y **eco** por plato.
- **Grabar la mezcla** en WAV. Queda en Música/DJ Latino.

## Cómo instalarla en tu teléfono

### Opción A: con un computador (Android Studio)
1. Instala Android Studio, que es gratis: https://developer.android.com/studio
2. En Android Studio: **File → Open** y elige esta carpeta (`android`).
3. Espera a que termine "Gradle sync". La primera vez descarga varias cosas y tarda unos minutos.
4. En el teléfono activa las **opciones de desarrollador** (toca 7 veces "Número de compilación" en *Ajustes → Acerca del teléfono*) y luego la **depuración USB**.
5. Conecta el teléfono por USB, elígelo arriba en Android Studio y pulsa **▶ Run**.

### Opción B: sin instalar nada (GitHub Actions)
1. Sube esta carpeta a un repositorio de GitHub. El archivo `.github/workflows/build-apk.yml` ya está incluido.
2. GitHub compila la app solo. Ve a la pestaña **Actions**, entra a la última ejecución y descarga **DJLatino-apk**.
3. Descomprime el archivo, pasa `app-debug.apk` al teléfono y ábrelo (Android te pedirá permitir "instalar apps desconocidas").

## Estructura
```
app/src/main/java/app/djlatino/
  engine/   motor de audio en Kotlin puro (platos, mezclador, EQ, filtro, eco, BPM, sintetizador, WAV)
  audio/    Android: decodificador (MediaCodec), salida (AudioTrack), micrófono, biblioteca
  ui/       pantallas Compose: consola, biblioteca, ViewModel
  ui/components, ui/theme   sistema de diseño (tokens generados desde design/tokens.json)
```
El motor (`engine/`) no depende de Android y tiene 32 pruebas automáticas que pasan: BPM de reguetón, merengue y salsa, EQ, filtro, loops, spinback, crossfader y grabación.

## Limitaciones conocidas de esta versión
- La latencia depende del teléfono: es correcta para mezclar, pero el scratch se siente mejor en equipos de gama media o alta. El motor en C++ con Oboe está planeado para más adelante (ver `architecture.md`).
- SYNC iguala el tempo pero no la fase del beat: el golpe se alinea a oído con + y − o con el anillo del plato.
- Todavía no hay pre-escucha por audífonos, automix ni micrófono en vivo. Están en el plan.
- La primera carga de una canción larga tarda unos segundos (la app la decodifica completa para poder hacer scratch).
